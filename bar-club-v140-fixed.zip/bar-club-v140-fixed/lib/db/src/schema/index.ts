import { pgTable, text, integer, boolean, timestamp, serial, varchar, index, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id:          serial("id").primaryKey(),
  vkUserId:    integer("vk_user_id").notNull().unique(),
  name:        text("name").notNull().default("Гость клуба"),
  avatarUrl:   text("avatar_url"),
  balance:     integer("balance").notNull().default(1000),
  rating:      integer("rating").notNull().default(0),
  stars:       integer("stars").notNull().default(0),
  activeCard:  varchar("active_card", { length: 32 }).notNull().default("Diamond"),
  isAdmin:     boolean("is_admin").notNull().default(false),
  isBanned:    boolean("is_banned").notNull().default(false),
  isMuted:     boolean("is_muted").notNull().default(false),
  muteUntil:   timestamp("mute_until"),
  gamesPlayed: integer("games_played").notNull().default(0),
  joinDate:    timestamp("join_date").defaultNow().notNull(),
  lastSeen:    timestamp("last_seen").defaultNow().notNull(),
}, (t) => [
  uniqueIndex("users_vk_user_id_idx").on(t.vkUserId),
]);

export const chatMessages = pgTable("chat_messages", {
  id:        serial("id").primaryKey(),
  userId:    integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  authorName:text("author_name").notNull(),
  text:      text("text").notNull(),
  isBot:     boolean("is_bot").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t) => [
  index("chat_messages_created_at_idx").on(t.createdAt),
]);

export const purchases = pgTable("purchases", {
  id:        serial("id").primaryKey(),
  userId:    integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  itemId:    varchar("item_id", { length: 64 }).notNull(),
  itemLabel: text("item_label").notNull(),
  currency:  varchar("currency", { length: 8 }).notNull().default("BJT"),
  price:     integer("price").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const dailyCheckins = pgTable("daily_checkins", {
  id:         serial("id").primaryKey(),
  userId:     integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  date:       varchar("date", { length: 10 }).notNull(),
  streak:     integer("streak").notNull().default(1),
  starsEarned:integer("stars_earned").notNull().default(5),
  createdAt:  timestamp("created_at").defaultNow().notNull(),
}, (t) => [
  uniqueIndex("daily_checkins_user_date_idx").on(t.userId, t.date),
]);

export const vkPayOrders = pgTable("vk_pay_orders", {
  id:          serial("id").primaryKey(),
  orderId:     varchar("order_id", { length: 64 }).notNull().unique(),
  userId:      integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  itemId:      varchar("item_id", { length: 64 }).notNull(),
  amountRub:   integer("amount_rub").notNull(),
  status:      varchar("status", { length: 16 }).notNull().default("pending"),
  createdAt:   timestamp("created_at").defaultNow().notNull(),
  resolvedAt:  timestamp("resolved_at"),
});

export const ratingVotes = pgTable("rating_votes", {
  id:         serial("id").primaryKey(),
  voterId:    integer("voter_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  targetId:   integer("target_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt:  timestamp("created_at").defaultNow().notNull(),
}, (t) => [
  index("rating_votes_voter_idx").on(t.voterId),
]);

export const insertUserSchema      = createInsertSchema(users).omit({ id: true, joinDate: true, lastSeen: true });
export const insertMessageSchema   = createInsertSchema(chatMessages).omit({ id: true, createdAt: true });
export const insertPurchaseSchema  = createInsertSchema(purchases).omit({ id: true, createdAt: true });

export type User         = typeof users.$inferSelect;
export type NewUser      = typeof users.$inferInsert;
export type ChatMessage  = typeof chatMessages.$inferSelect;
export type Purchase     = typeof purchases.$inferSelect;
export type DailyCheckin = typeof dailyCheckins.$inferSelect;
export type VkPayOrder   = typeof vkPayOrders.$inferSelect;
