# Bar-Club v1.0.40-fixed — Список изменений

## Безопасность (Критично)
- ✅ Добавлена HMAC-SHA256 проверка VK launch params на сервере (`lib/vkAuth.ts`)
- ✅ Реализован JWT на встроенном Node.js crypto (HMAC-HS256, без внешних зависимостей)
- ✅ `isAdmin` теперь определяется только сервером — убрана клиентская проверка
- ✅ Strict CORS: whitelist vk.com / vk.ru / m.vk.com (+ localhost в dev)
- ✅ Security headers: X-Content-Type-Options, X-Frame-Options, X-XSS-Protection, HSTS, Permissions-Policy
- ✅ Rate limiting: 120 req/мин (production) / 1000 (dev) — без внешних пакетов
- ✅ Logout очищает localStorage и токен

## База данных
- ✅ Написана полная схема Drizzle ORM: `users`, `chat_messages`, `purchases`, `daily_checkins`, `vk_pay_orders`, `rating_votes`
- ✅ Типы и Zod схемы экспортированы из `@workspace/db`

## API (backend)
- ✅ `POST /api/auth/vk` — верификация launch params, upsert пользователя, возврат JWT
- ✅ `GET/POST /api/messages` — история чата (24ч), отправка с XSS-санитизацией и cooldown 2500ms
- ✅ `DELETE /api/messages` — очистка чата (только admin)
- ✅ `GET /api/profile` — профиль текущего пользователя
- ✅ `PUT /api/profile` — обновление профиля
- ✅ `GET /api/leaderboard` — топ-30 по рейтингу
- ✅ `POST /api/profile/vote` — голосование 1 раз в 24ч
- ✅ `GET /api/shop/catalog` — каталог товаров
- ✅ `POST /api/shop/purchase` — покупка с дебетованием баланса
- ✅ `POST /api/daily/checkin` — ежедневный вход, прогрессивные Stars (5→75), серии
- ✅ `GET /api/daily/status` — статус входа и история 7 дней
- ✅ `POST /api/admin/mute|unmute|ban|unban|clear-chat|grant-bjt` — всё с серверной проверкой isAdmin

## Real-time
- ✅ Socket.IO добавлен к HTTP серверу (`index.ts`)
- ✅ Реальный online-счётчик из подключений Socket.IO
- ✅ Events: `online_count`, `new_message`, `send_message`

## Frontend (bar-app)
- ✅ `lib/api.ts` — типизированный API-клиент с Bearer auth
- ✅ `lib/vk.ts` — убран ADMIN_VK_ID, правильный разбор launch params
- ✅ `lib/utils.ts` — `getInitials()` вынесен в shared (убрано дублирование в bar.tsx / profile.tsx)
- ✅ `context.tsx` — реальный VK auth через сервер; статус сервера через /healthz каждые 30с; trim сообщений до 100
- ✅ `pages/bar.tsx` — счётчик символов (цветной: серый→жёлтый→красный), метка «бот» на автосообщениях, пустое состояние чата
- ✅ `pages/profile.tsx` — удалена кнопка «+BJT», добавлен ежедневный вход со Stars, показ звёзд
- ✅ `pages/not-found.tsx` — тёмная тема, кнопка «На главную»
- ✅ `components/admin-modal.tsx` — все действия подключены к реальному API, loader-индикаторы
- ✅ `.env.example` — полный список переменных с комментариями
