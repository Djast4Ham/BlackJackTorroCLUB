import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import app from "./app.js";
import { logger } from "./lib/logger.js";
import { db } from "@workspace/db";
import { chatMessages } from "@workspace/db/schema";
import { desc, gt } from "drizzle-orm";

const rawPort = process.env["API_PORT"] ?? process.env["PORT"] ?? "3000";
const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const httpServer = createServer(app);

// Socket.IO for real-time
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: process.env.NODE_ENV !== "production"
      ? ["http://localhost:5173", "http://127.0.0.1:5173"]
      : ["https://vk.com", "https://m.vk.com", "https://vk.ru"],
    credentials: true,
  },
  transports: ["websocket", "polling"],
});

let onlineCount = 0;

io.on("connection", (socket) => {
  onlineCount++;
  io.emit("online_count", onlineCount);
  logger.info({ socketId: socket.id, onlineCount }, "Client connected");

  socket.on("disconnect", () => {
    onlineCount = Math.max(0, onlineCount - 1);
    io.emit("online_count", onlineCount);
    logger.info({ socketId: socket.id, onlineCount }, "Client disconnected");
  });

  socket.on("send_message", async (data: { text: string; authorName: string; userId: number }) => {
    io.emit("new_message", {
      id: Date.now().toString(),
      author: data.authorName,
      text: data.text,
      time: new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" }),
      reactions: {},
    });
  });
});

// Expose io for routes (attach to app)
(app as unknown as Record<string, unknown>).io = io;

httpServer.listen(port, () => {
  logger.info({ port }, "Server listening");
});
