import { Router } from "express";
import { db } from "@workspace/db";
import { users, chatMessages } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { requireAdmin } from "../middlewares/auth.js";
import { z } from "zod";

const router = Router();
router.use(requireAdmin);

const TargetSchema = z.object({ targetVkId: z.number().int().positive() });

async function getTarget(targetVkId: number) {
  const [u] = await db.select().from(users).where(eq(users.vkUserId, targetVkId)).limit(1);
  return u;
}

router.post("/admin/mute", async (req, res) => {
  const parsed = TargetSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Неверные данные" }); return; }
  const user = await getTarget(parsed.data.targetVkId);
  if (!user) { res.status(404).json({ error: "Пользователь не найден" }); return; }
  const muteUntil = new Date(Date.now() + 15 * 60 * 1000);
  const [updated] = await db.update(users).set({ isMuted: true, muteUntil }).where(eq(users.id, user.id)).returning();
  res.json({ ok: true, muteUntil: updated.muteUntil, message: `Мут до ${muteUntil.toLocaleTimeString("ru-RU")}` });
});

router.post("/admin/unmute", async (req, res) => {
  const parsed = TargetSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Неверные данные" }); return; }
  const user = await getTarget(parsed.data.targetVkId);
  if (!user) { res.status(404).json({ error: "Пользователь не найден" }); return; }
  await db.update(users).set({ isMuted: false, muteUntil: null }).where(eq(users.id, user.id));
  res.json({ ok: true });
});

router.post("/admin/ban", async (req, res) => {
  const parsed = TargetSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Неверные данные" }); return; }
  const user = await getTarget(parsed.data.targetVkId);
  if (!user) { res.status(404).json({ error: "Пользователь не найден" }); return; }
  if (user.isAdmin) { res.status(403).json({ error: "Нельзя заблокировать администратора" }); return; }
  await db.update(users).set({ isBanned: true }).where(eq(users.id, user.id));
  res.json({ ok: true });
});

router.post("/admin/unban", async (req, res) => {
  const parsed = TargetSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Неверные данные" }); return; }
  const user = await getTarget(parsed.data.targetVkId);
  if (!user) { res.status(404).json({ error: "Пользователь не найден" }); return; }
  await db.update(users).set({ isBanned: false }).where(eq(users.id, user.id));
  res.json({ ok: true });
});

router.post("/admin/clear-chat", async (_req, res) => {
  await db.delete(chatMessages);
  res.json({ ok: true });
});

router.post("/admin/grant-bjt", async (req, res) => {
  const Schema = z.object({ targetVkId: z.number().int().positive(), amount: z.number().int().min(1).max(100000) });
  const parsed = Schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Неверные данные" }); return; }
  const user = await getTarget(parsed.data.targetVkId);
  if (!user) { res.status(404).json({ error: "Пользователь не найден" }); return; }
  const [updated] = await db
    .update(users).set({ balance: user.balance + parsed.data.amount }).where(eq(users.id, user.id)).returning();
  res.json({ balance: updated.balance });
});

export default router;
