import { Router } from "express";
import { db } from "@workspace/db";
import { users, dailyCheckins } from "@workspace/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";

const router = Router();

// Russian timezone offset: UTC+3
const TZ_OFFSET_MS = 3 * 60 * 60 * 1000;

function todayMoscow(): string {
  const d = new Date(Date.now() + TZ_OFFSET_MS);
  return d.toISOString().slice(0, 10);
}

function yesterdayMoscow(): string {
  const d = new Date(Date.now() + TZ_OFFSET_MS - 24 * 60 * 60 * 1000);
  return d.toISOString().slice(0, 10);
}

function starsForDay(dayOfMonth: number, daysInMonth: number): number {
  const MIN = 5, MAX = 75;
  return Math.round(MIN + ((MAX - MIN) * (dayOfMonth - 1)) / Math.max(daysInMonth - 1, 1));
}

router.post("/daily/checkin", requireAuth, async (req, res) => {
  const today     = todayMoscow();
  const yesterday = yesterdayMoscow();
  const userId    = req.user!.userId;

  const existing = await db
    .select().from(dailyCheckins)
    .where(and(eq(dailyCheckins.userId, userId), eq(dailyCheckins.date, today)))
    .limit(1);

  if (existing.length > 0) {
    res.status(409).json({ error: "Уже отмечен сегодня", nextCheckin: today + "T21:00:00+03:00" });
    return;
  }

  const prev = await db
    .select().from(dailyCheckins)
    .where(and(eq(dailyCheckins.userId, userId), eq(dailyCheckins.date, yesterday)))
    .limit(1);

  const streak = prev.length > 0 ? prev[0].streak + 1 : 1;

  const d = new Date(Date.now() + TZ_OFFSET_MS);
  const stars = starsForDay(d.getUTCDate(), new Date(d.getUTCFullYear(), d.getUTCMonth() + 1, 0).getUTCDate());

  await db.insert(dailyCheckins).values({ userId, date: today, streak, starsEarned: stars });
  const [updated] = await db
    .update(users).set({ stars: (await db.select().from(users).where(eq(users.id, userId)).limit(1))[0].stars + stars })
    .where(eq(users.id, userId)).returning();

  res.json({ streak, starsEarned: stars, totalStars: updated.stars, date: today });
});

router.get("/daily/status", requireAuth, async (req, res) => {
  const today  = todayMoscow();
  const userId = req.user!.userId;

  const [todayRow] = await db
    .select().from(dailyCheckins)
    .where(and(eq(dailyCheckins.userId, userId), eq(dailyCheckins.date, today)))
    .limit(1);

  const last7 = await db
    .select().from(dailyCheckins)
    .where(eq(dailyCheckins.userId, userId))
    .orderBy(desc(dailyCheckins.date))
    .limit(7);

  res.json({
    checkedToday: !!todayRow,
    streak: todayRow?.streak ?? last7[0]?.streak ?? 0,
    last7: last7.map(r => ({ date: r.date, stars: r.starsEarned })),
  });
});

export default router;
