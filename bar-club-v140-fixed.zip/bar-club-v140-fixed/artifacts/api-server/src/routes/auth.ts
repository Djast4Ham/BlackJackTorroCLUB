import { Router } from "express";
import { db } from "@workspace/db";
import { users } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { verifyVkLaunchParams, parseVkLaunchParams } from "../lib/vkAuth.js";
import { signToken } from "../lib/jwt.js";
import { z } from "zod";

const router = Router();

const VK_CLIENT_SECRET = process.env.VK_CLIENT_SECRET ?? "";
const ADMIN_VK_ID      = Number(process.env.ADMIN_VK_ID ?? "0");
const DEV_SKIP_HMAC    = process.env.NODE_ENV !== "production" && process.env.VK_SKIP_HMAC_VERIFY === "true";

const LoginSchema = z.object({
  launchParams: z.string().min(1),
});

router.post("/auth/vk", async (req, res) => {
  const parsed = LoginSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Неверный запрос" });
    return;
  }

  const params = parseVkLaunchParams(parsed.data.launchParams);

  if (!DEV_SKIP_HMAC) {
    if (!VK_CLIENT_SECRET) {
      res.status(500).json({ error: "VK_CLIENT_SECRET не настроен" });
      return;
    }
    if (!verifyVkLaunchParams(params, VK_CLIENT_SECRET)) {
      res.status(401).json({ error: "Подпись VK не прошла проверку" });
      return;
    }

    const ts = Number(params["vk_ts"] ?? 0);
    if (Math.abs(Date.now() / 1000 - ts) > 300) {
      res.status(401).json({ error: "Параметры запуска устарели" });
      return;
    }
  }

  const vkUserId = Number(params["vk_user_id"] ?? 0);
  if (!vkUserId) {
    res.status(400).json({ error: "Отсутствует vk_user_id" });
    return;
  }

  const isAdmin = vkUserId === ADMIN_VK_ID;

  const [user] = await db
    .insert(users)
    .values({ vkUserId, name: `VK ${vkUserId}`, isAdmin, lastSeen: new Date() })
    .onConflictDoUpdate({
      target: users.vkUserId,
      set: { isAdmin, lastSeen: new Date() },
    })
    .returning();

  const token = signToken({ userId: user.id, vkUserId: user.vkUserId, isAdmin: user.isAdmin });

  res.json({
    token,
    user: {
      id: user.id,
      vkUserId: user.vkUserId,
      name: user.name,
      avatarUrl: user.avatarUrl,
      balance: user.balance,
      rating: user.rating,
      stars: user.stars,
      activeCard: user.activeCard,
      isAdmin: user.isAdmin,
      gamesPlayed: user.gamesPlayed,
    },
  });
});

export default router;
