import { Router } from "express";
import { db } from "@workspace/db";
import { users, purchases } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";
import { z } from "zod";

const router = Router();

const CATALOG = [
  { id: "card-cosmos",    label: "Карта «Космос»",    price: 500,  currency: "BJT" as const },
  { id: "card-ruby",      label: "Карта «Ruby»",      price: 1000, currency: "BJT" as const },
  { id: "card-platinum",  label: "Карта «Platinum»",  price: 2500, currency: "BJT" as const },
  { id: "card-diamond",   label: "Карта «Diamond»",   price: 5000, currency: "BJT" as const },
];

const CARD_MAP: Record<string, string> = {
  "card-cosmos":   "Cosmos",
  "card-ruby":     "Ruby",
  "card-platinum": "Platinum",
  "card-diamond":  "Diamond",
};

router.get("/shop/catalog", (_req, res) => {
  res.json(CATALOG);
});

const PurchaseSchema = z.object({ itemId: z.string().min(1) });

router.post("/shop/purchase", requireAuth, async (req, res) => {
  const parsed = PurchaseSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Неверный запрос" }); return; }

  const item = CATALOG.find(c => c.id === parsed.data.itemId);
  if (!item) { res.status(404).json({ error: "Товар не найден" }); return; }

  const [user] = await db.select().from(users).where(eq(users.id, req.user!.userId)).limit(1);
  if (!user) { res.status(404).json({ error: "Пользователь не найден" }); return; }

  if (user.balance < item.price) {
    res.status(402).json({ error: `Недостаточно BJT. Нужно ${item.price}, есть ${user.balance}` });
    return;
  }

  const newBalance = user.balance - item.price;
  const newCard    = CARD_MAP[item.id] ?? user.activeCard;

  await db.insert(purchases).values({
    userId: user.id, itemId: item.id, itemLabel: item.label, currency: item.currency, price: item.price,
  });

  const [updated] = await db
    .update(users)
    .set({ balance: newBalance, activeCard: newCard })
    .where(eq(users.id, user.id))
    .returning();

  res.json({ balance: updated.balance, activeCard: updated.activeCard });
});

export default router;
