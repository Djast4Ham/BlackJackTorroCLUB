import { Router } from "express";
import { db } from "@workspace/db";
import { chatMessages, users } from "@workspace/db/schema";
import { desc, eq, and, gt } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";
import { z } from "zod";

const router = Router();

const MSG_MAX_LEN = 280;
const MSG_HISTORY = 100;
const MSG_COOLDOWN_MS = 2500;
const lastSent = new Map<number, number>();

router.get("/messages", async (_req, res) => {
  const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const rows = await db
    .select()
    .from(chatMessages)
    .where(gt(chatMessages.createdAt, cutoff))
    .orderBy(desc(chatMessages.createdAt))
    .limit(MSG_HISTORY);
  res.json(rows.reverse());
});

const SendSchema = z.object({
  text: z.string().min(1).max(MSG_MAX_LEN).transform(s =>
    s.replace(/[<>"'`]/g, c => ({ "<":"&lt;",">":`&gt;`,"\"":"&quot;","'":"&#39;","`":"&#96;" }[c] ?? c))
  ),
});

router.post("/messages", requireAuth, async (req, res) => {
  const user = req.user!;

  const parsed = SendSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Неверное сообщение" });
    return;
  }

  const [dbUser] = await db.select().from(users).where(eq(users.id, user.userId)).limit(1);
  if (!dbUser || dbUser.isBanned) {
    res.status(403).json({ error: "Доступ запрещён" });
    return;
  }
  if (dbUser.isMuted && dbUser.muteUntil && dbUser.muteUntil > new Date()) {
    res.status(403).json({ error: `Вы в муте до ${dbUser.muteUntil.toLocaleTimeString("ru-RU")}` });
    return;
  }

  const lastMs = lastSent.get(user.userId) ?? 0;
  if (Date.now() - lastMs < MSG_COOLDOWN_MS) {
    res.status(429).json({ error: "Слишком быстро, подождите" });
    return;
  }
  lastSent.set(user.userId, Date.now());

  const [msg] = await db
    .insert(chatMessages)
    .values({ userId: user.userId, authorName: dbUser.name, text: parsed.data.text })
    .returning();

  res.status(201).json(msg);
});

router.delete("/messages", requireAuth, async (req, res) => {
  if (!req.user?.isAdmin) {
    res.status(403).json({ error: "Только для администраторов" });
    return;
  }
  await db.delete(chatMessages);
  res.json({ ok: true });
});

export default router;
