import { Router } from "express";
import { db } from "@workspace/db";
import { users, ratingVotes } from "@workspace/db/schema";
import { eq, desc, and, gt } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";
import { z } from "zod";

const router = Router();

router.get("/profile", requireAuth, async (req, res) => {
  const [user] = await db.select().from(users).where(eq(users.id, req.user!.userId)).limit(1);
  if (!user) { res.status(404).json({ error: "Пользователь не найден" }); return; }
  res.json(user);
});

router.put("/profile", requireAuth, async (req, res) => {
  const Schema = z.object({
    name:       z.string().min(1).max(40).optional(),
    avatarUrl:  z.string().url().optional().nullable(),
    activeCard: z.enum(["Diamond", "Platinum", "Ruby", "Cosmos"]).optional(),
  });
  const parsed = Schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Неверные данные" }); return; }
  const [updated] = await db
    .update(users).set(parsed.data).where(eq(users.id, req.user!.userId)).returning();
  res.json(updated);
});

router.get("/leaderboard", async (_req, res) => {
  const top = await db
    .select({ id: users.id, name: users.name, rating: users.rating, activeCard: users.activeCard, avatarUrl: users.avatarUrl })
    .from(users)
    .orderBy(desc(users.rating))
    .limit(30);
  res.json(top);
});

router.post("/profile/vote", requireAuth, async (req, res) => {
  const Schema = z.object({ targetId: z.number().int().positive() });
  const parsed = Schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Неверные данные" }); return; }

  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const existing = await db
    .select()
    .from(ratingVotes)
    .where(and(eq(ratingVotes.voterId, req.user!.userId), gt(ratingVotes.createdAt, since)))
    .limit(1);

  if (existing.length > 0) {
    res.status(429).json({ error: "Голосовать можно раз в 24 часа" });
    return;
  }

  await db.insert(ratingVotes).values({ voterId: req.user!.userId, targetId: parsed.data.targetId });
  const [updated] = await db
    .update(users).set({ rating: users.rating + 1 }).where(eq(users.id, parsed.data.targetId)).returning();
  res.json({ newRating: updated.rating });
});

export default router;
