import { Router, type IRouter } from "express";
import healthRouter  from "./health.js";
import authRouter    from "./auth.js";
import messagesRouter from "./messages.js";
import profileRouter  from "./profile.js";
import shopRouter     from "./shop.js";
import adminRouter    from "./admin.js";
import dailyRouter    from "./daily.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(messagesRouter);
router.use(profileRouter);
router.use(shopRouter);
router.use(adminRouter);
router.use(dailyRouter);

export default router;
