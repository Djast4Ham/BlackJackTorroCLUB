import { createHmac, timingSafeEqual } from "crypto";

export interface TokenPayload {
  userId: number;
  vkUserId: number;
  isAdmin: boolean;
  iat: number;
  exp: number;
}

const JWT_SECRET = process.env.JWT_SECRET ?? "change-me-in-production-32-chars!!";
const TOKEN_TTL_S = 60 * 60 * 24 * 7; // 7 days

function b64url(s: string): string {
  return Buffer.from(s).toString("base64url");
}

function sign(header: string, payload: string): string {
  return createHmac("sha256", JWT_SECRET)
    .update(`${header}.${payload}`)
    .digest("base64url");
}

export function signToken(payload: Omit<TokenPayload, "iat" | "exp">): string {
  const now = Math.floor(Date.now() / 1000);
  const full: TokenPayload = { ...payload, iat: now, exp: now + TOKEN_TTL_S };
  const header  = b64url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const body    = b64url(JSON.stringify(full));
  const sig     = sign(header, body);
  return `${header}.${body}.${sig}`;
}

export function verifyToken(token: string): TokenPayload | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const [header, body, sig] = parts;
    const expected = sign(header, body);
    const actual = Buffer.from(sig, "base64url");
    const exp    = Buffer.from(expected, "base64url");
    if (actual.length !== exp.length) return null;
    if (!timingSafeEqual(actual, exp)) return null;

    const payload = JSON.parse(Buffer.from(body, "base64url").toString()) as TokenPayload;
    if (Math.floor(Date.now() / 1000) > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}
