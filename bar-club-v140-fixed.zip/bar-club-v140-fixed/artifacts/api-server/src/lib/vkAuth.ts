import { createHmac } from "crypto";

/**
 * Verifies VK Mini App launch params using HMAC-SHA256.
 * https://dev.vk.com/ru/mini-apps/launch-params
 */
export function verifyVkLaunchParams(
  query: Record<string, string>,
  clientSecret: string,
): boolean {
  const vkParams: Record<string, string> = {};
  for (const [key, value] of Object.entries(query)) {
    if (key.startsWith("vk_")) vkParams[key] = value;
  }

  const sign = query["sign"];
  if (!sign) return false;

  const checkString = Object.keys(vkParams)
    .sort()
    .map((k) => `${k}=${vkParams[k]}`)
    .join("&");

  const expectedSign = createHmac("sha256", clientSecret)
    .update(checkString)
    .digest("base64url");

  if (expectedSign.length !== sign.length) return false;

  // Timing-safe comparison
  let mismatch = 0;
  for (let i = 0; i < expectedSign.length; i++) {
    mismatch |= expectedSign.charCodeAt(i) ^ sign.charCodeAt(i);
  }
  return mismatch === 0;
}

export function parseVkLaunchParams(rawQuery: string): Record<string, string> {
  const params: Record<string, string> = {};
  for (const [k, v] of new URLSearchParams(rawQuery).entries()) {
    params[k] = v;
  }
  return params;
}
