import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes/index.js";
import { logger } from "./lib/logger.js";

const app: Express = express();

const ALLOWED_ORIGINS = [
  "https://vk.com",
  "https://m.vk.com",
  "https://vk.ru",
  "https://m.vk.ru",
  ...(process.env.NODE_ENV !== "production"
    ? ["http://localhost:5173", "http://127.0.0.1:5173"]
    : []),
];

app.use(pinoHttp({
  logger,
  serializers: {
    req(req) { return { id: req.id, method: req.method, url: req.url?.split("?")[0] }; },
    res(res) { return { statusCode: res.statusCode }; },
  },
}));

app.use(cors({
  origin: (origin, cb) => {
    if (!origin || ALLOWED_ORIGINS.includes(origin)) { cb(null, true); return; }
    cb(new Error("CORS: Origin not allowed"));
  },
  credentials: true,
}));

// Security headers (manual, no helmet dependency required)
app.use((_req: Request, res: Response, next: NextFunction) => {
  res.setHeader("X-Content-Type-Options",   "nosniff");
  res.setHeader("X-Frame-Options",          "SAMEORIGIN");
  res.setHeader("X-XSS-Protection",         "1; mode=block");
  res.setHeader("Referrer-Policy",          "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy",       "camera=(), microphone=(), geolocation=()");
  if (process.env.NODE_ENV === "production") {
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  }
  next();
});

// Rate limiting (manual, no express-rate-limit required)
const reqCounts = new Map<string, { count: number; reset: number }>();
const RATE_LIMIT = process.env.NODE_ENV === "production" ? 120 : 1000;
const RATE_WINDOW_MS = 60_000;

app.use((req: Request, res: Response, next: NextFunction) => {
  const key = req.ip ?? "anon";
  const now = Date.now();
  const entry = reqCounts.get(key);

  if (!entry || entry.reset < now) {
    reqCounts.set(key, { count: 1, reset: now + RATE_WINDOW_MS });
    next(); return;
  }
  entry.count++;
  if (entry.count > RATE_LIMIT) {
    res.status(429).json({ error: "Слишком много запросов. Попробуйте позже." });
    return;
  }
  next();
});

app.use(express.json({ limit: "32kb" }));
app.use(express.urlencoded({ extended: false }));

app.use("/api", router);

// 404 handler
app.use((_req: Request, res: Response) => {
  res.status(404).json({ error: "Маршрут не найден" });
});

// Error handler
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  logger.error({ err }, "Unhandled error");
  res.status(500).json({ error: "Внутренняя ошибка сервера" });
});

export default app;
