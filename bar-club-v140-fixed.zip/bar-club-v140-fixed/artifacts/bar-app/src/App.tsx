import { Switch, Route, Router as WouterRouter, Redirect, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppProvider, useApp } from "@/lib/context";
import { Layout } from "@/components/layout";
import LoginScreen from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import BarRoom from "@/pages/bar";
import PremiumShop from "@/pages/shop";
import PlayerProfile from "@/pages/profile";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

const PAGE_VARIANTS = {
  initial: { opacity: 0, y: 14 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.22, ease: "easeOut" as const } },
  exit:    { opacity: 0, y: -10, transition: { duration: 0.18, ease: "easeIn" as const } },
};

function PageWrap({ children }: { children: React.ReactNode }) {
  return (
    <motion.div variants={PAGE_VARIANTS} initial="initial" animate="animate" exit="exit">
      {children}
    </motion.div>
  );
}

function AppShell() {
  const { state } = useApp();
  const [location] = useLocation();

  if (!state.isLoggedIn) {
    return (
      <AnimatePresence mode="wait" initial={false}>
        <LoginScreen key="login" />
      </AnimatePresence>
    );
  }

  return (
    <Layout>
      <AnimatePresence mode="wait" initial={false}>
        <Switch key={location} location={location}>
          <Route path="/">
            <Redirect to="/dashboard" />
          </Route>
          <Route path="/dashboard">
            <PageWrap key="dashboard"><Dashboard /></PageWrap>
          </Route>
          <Route path="/bar">
            <PageWrap key="bar"><BarRoom /></PageWrap>
          </Route>
          <Route path="/shop">
            <PageWrap key="shop"><PremiumShop /></PageWrap>
          </Route>
          <Route path="/profile">
            <PageWrap key="profile"><PlayerProfile /></PageWrap>
          </Route>
          <Route>
            <PageWrap key="404"><NotFound /></PageWrap>
          </Route>
        </Switch>
      </AnimatePresence>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <AppShell />
          </WouterRouter>
        </AppProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
