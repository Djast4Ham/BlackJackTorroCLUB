import { useState } from "react";
import { motion } from "framer-motion";
import { Shield, VolumeX, Volume2, Ban, CheckCircle, Trash2, Coins, X, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog.js";
import { useToast } from "../hooks/use-toast.js";
import { useApp } from "../lib/context.js";
import { api } from "../lib/api.js";

interface Props { open: boolean; onOpenChange: (v: boolean) => void; }

export function AdminModal({ open, onOpenChange }: Props) {
  const { state, logAdminAction } = useApp();
  const { toast } = useToast();
  const [targetId, setTargetId] = useState("");
  const [grantAmount, setGrantAmount] = useState("100");
  const [loading, setLoading] = useState<string | null>(null);

  const vkId = () => {
    const n = Number(targetId.trim());
    if (!n || !Number.isFinite(n)) { toast({ title: "Введите корректный VK ID", variant: "destructive" }); return null; }
    return n;
  };

  const run = async (key: string, fn: () => Promise<{ ok: boolean; error?: string } | { ok: true; message?: string }>) => {
    setLoading(key);
    try {
      const r = await fn();
      if (!r.ok) { toast({ title: (r as { error?: string }).error ?? "Ошибка", variant: "destructive" }); }
      else {
        const msg = (r as { message?: string }).message;
        toast({ title: msg ?? "Готово", className: "border-primary bg-card text-primary" });
        logAdminAction(`${key} → VK ${targetId}`);
      }
    } finally { setLoading(null); }
  };

  const actions = [
    { key: "mute",   label: "Мут 15 мин",  Icon: VolumeX,      color: "#f59e0b", fn: () => { const id = vkId(); return id ? api.adminMute(id)   : Promise.resolve({ ok: false, error: "Нет ID" } as const); } },
    { key: "unmute", label: "Снять мут",   Icon: Volume2,      color: "#34d399", fn: () => { const id = vkId(); return id ? api.adminUnmute(id) : Promise.resolve({ ok: false, error: "Нет ID" } as const); } },
    { key: "ban",    label: "Заблокировать",Icon: Ban,          color: "#ef4444", fn: () => { const id = vkId(); return id ? api.adminBan(id)    : Promise.resolve({ ok: false, error: "Нет ID" } as const); } },
    { key: "unban",  label: "Разблокировать",Icon: CheckCircle, color: "#60a5fa", fn: () => { const id = vkId(); return id ? api.adminUnban(id)  : Promise.resolve({ ok: false, error: "Нет ID" } as const); } },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm bg-[#12101c] border border-primary/25 text-foreground p-5">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-serif text-lg gold-gradient-text">
            <Shield size={18} className="text-primary" /> Администрирование
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          {/* Target ID */}
          <div className="space-y-1.5">
            <label className="text-[10px] text-muted-foreground/60 tracking-wider uppercase">VK ID пользователя</label>
            <input value={targetId} onChange={e => setTargetId(e.target.value)}
              placeholder="например: 123456789" data-testid="admin-target-id"
              className="w-full bg-black/40 border border-primary/20 rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/30 focus:outline-none focus:border-primary/50" />
          </div>

          {/* Moderation buttons */}
          <div className="grid grid-cols-2 gap-2">
            {actions.map(({ key, label, Icon, color, fn }) => (
              <motion.button key={key} whileTap={{ scale: 0.96 }}
                onClick={() => run(key, fn as Parameters<typeof run>[1])}
                disabled={loading !== null}
                className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-medium transition-all disabled:opacity-50"
                style={{ background: `${color}14`, border: `1px solid ${color}40`, color }}
                data-testid={`admin-btn-${key}`}>
                {loading === key ? <Loader2 size={13} className="animate-spin" /> : <Icon size={13} />}
                {label}
              </motion.button>
            ))}
          </div>

          <div className="h-px bg-primary/10" />

          {/* Grant BJT */}
          <div className="space-y-2">
            <label className="text-[10px] text-muted-foreground/60 tracking-wider uppercase">Начислить BJT</label>
            <div className="flex gap-2">
              <input value={grantAmount} onChange={e => setGrantAmount(e.target.value)}
                type="number" min="1" max="100000" placeholder="100" data-testid="admin-grant-amount"
                className="flex-1 bg-black/40 border border-primary/20 rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/30 focus:outline-none focus:border-primary/50" />
              <motion.button whileTap={{ scale: 0.96 }}
                onClick={() => {
                  const id = vkId(); if (!id) return;
                  const amt = Number(grantAmount);
                  if (!amt || amt < 1) { toast({ title: "Неверная сумма", variant: "destructive" }); return; }
                  run("grant", () => api.adminGrantBjt(id, amt));
                }}
                disabled={loading !== null}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium disabled:opacity-50"
                style={{ background: "rgba(201,168,76,0.12)", border: "1px solid rgba(201,168,76,0.35)", color: "#f0d080" }}
                data-testid="admin-btn-grant">
                {loading === "grant" ? <Loader2 size={13} className="animate-spin" /> : <Coins size={13} />} Дать
              </motion.button>
            </div>
          </div>

          <div className="h-px bg-primary/10" />

          {/* Clear chat */}
          <motion.button whileTap={{ scale: 0.97 }}
            onClick={() => run("clear", () => api.adminClearChat())}
            disabled={loading !== null}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-medium transition-all disabled:opacity-50"
            style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.35)", color: "#f87171" }}
            data-testid="admin-btn-clear-chat">
            {loading === "clear" ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
            Очистить чат
          </motion.button>

          {/* Log */}
          {state.adminLog.length > 0 && (
            <div className="space-y-1">
              <p className="text-[9px] text-muted-foreground/40 tracking-wider uppercase">Последние действия</p>
              <div className="space-y-0.5 max-h-20 overflow-y-auto">
                {state.adminLog.slice(0, 8).map((l, i) => (
                  <div key={i} className="flex gap-2 text-[10px]">
                    <span className="text-primary/40 shrink-0">{l.time}</span>
                    <span className="text-muted-foreground/60">{l.action}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
