import { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Home, Wine, ShoppingBag, User, ShieldAlert, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { AdminModal } from './admin-modal';
import { useApp } from '../lib/context';

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const [adminOpen, setAdminOpen] = useState(false);
  const { state, logout } = useApp();

  // Track unread messages: update "seen" count whenever user is on /bar
  const seenCountRef = useRef(state.chatMessages.length);
  useEffect(() => {
    if (location === '/bar') {
      seenCountRef.current = state.chatMessages.length;
    }
  }, [location, state.chatMessages.length]);

  const unreadBar = location !== '/bar' && state.chatMessages.length > seenCountRef.current;
  const unreadCount = Math.max(0, state.chatMessages.length - seenCountRef.current);

  const navItems = [
    { href: '/dashboard', icon: Home,        label: 'Главная' },
    { href: '/bar',       icon: Wine,        label: 'Бар'     },
    { href: '/shop',      icon: ShoppingBag, label: 'Магазин' },
    { href: '/profile',   icon: User,        label: 'Профиль' },
  ];

  const handleLogout = () => {
    logout();
    setLocation('/');
  };

  return (
    <div className="min-h-[100dvh] w-full flex flex-col max-w-5xl mx-auto relative bg-[#0a0a0f] shadow-2xl">
      <main className="flex-1 overflow-y-auto pb-16 no-scrollbar min-h-0">
        {children}
      </main>

      {/* Admin floating button */}
      {state.player.isAdmin && (
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.92 }}
        onClick={() => setAdminOpen(true)}
        className="fixed bottom-20 right-4 z-40 p-2.5 rounded-full text-white border transition-all"
        style={{
          background: 'rgba(107,30,42,0.85)',
          border: '1px solid rgba(201,168,76,0.25)',
          boxShadow: '0 0 14px rgba(107,30,42,0.5)',
          backdropFilter: 'blur(8px)',
        }}
        data-testid="button-admin"
        title="Панель администратора"
      >
        <ShieldAlert size={16} />
      </motion.button>
      )}

      {/* Logout button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.92 }}
        onClick={handleLogout}
        className="fixed bottom-20 left-4 z-40 p-2.5 rounded-full text-muted-foreground border transition-all hover:text-destructive"
        style={{
          background: 'rgba(10,10,15,0.85)',
          border: '1px solid rgba(255,255,255,0.08)',
          backdropFilter: 'blur(8px)',
        }}
        data-testid="button-logout"
        title="Выйти"
      >
        <LogOut size={16} />
      </motion.button>

      {/* Bottom nav */}
      <nav
        className="fixed bottom-0 left-0 right-0 max-w-5xl mx-auto h-16 px-2 flex items-stretch justify-around z-50"
        style={{
          background: 'rgba(10,10,15,0.97)',
          borderTop: '1px solid rgba(201,168,76,0.18)',
          backdropFilter: 'blur(16px)',
        }}
      >
        {navItems.map((item) => {
          const isActive = location === item.href;
          const showBadge = item.href === '/bar' && unreadBar;

          return (
            <Link
              key={item.href}
              href={item.href}
              className="flex-1 flex flex-col items-center justify-center gap-0.5 relative group"
              data-testid={`nav-${item.href.slice(1)}`}
            >
              {/* Active top bar */}
              <AnimatePresence>
                {isActive && (
                  <motion.div
                    layoutId="nav-indicator"
                    className="absolute top-0 w-10 h-0.5 rounded-b-full"
                    style={{ background: 'linear-gradient(90deg, #c9a84c, #f0d080)' }}
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: 1 }}
                    exit={{ scaleX: 0 }}
                    transition={{ duration: 0.2 }}
                  />
                )}
              </AnimatePresence>

              {/* Icon + badge */}
              <div className="relative">
                <item.icon
                  size={22}
                  className="transition-all duration-200"
                  style={{
                    color: isActive ? '#f0d080' : 'rgba(160,144,128,0.65)',
                    filter: isActive ? 'drop-shadow(0 0 6px rgba(201,168,76,0.55))' : 'none',
                    transform: isActive ? 'scale(1.12)' : 'scale(1)',
                  }}
                />
                <AnimatePresence>
                  {showBadge && (
                    <motion.span
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      exit={{ scale: 0 }}
                      className="absolute -top-1 -right-1.5 min-w-[14px] h-3.5 rounded-full bg-primary flex items-center justify-center text-[9px] font-bold text-primary-foreground px-0.5"
                      style={{ boxShadow: '0 0 6px rgba(201,168,76,0.8)' }}
                    >
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </motion.span>
                  )}
                </AnimatePresence>
              </div>

              <span
                className="text-[10px] font-medium transition-colors duration-200"
                style={{ color: isActive ? '#f0d080' : 'rgba(160,144,128,0.55)' }}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>

      <AdminModal open={adminOpen} onOpenChange={setAdminOpen} />
    </div>
  );
}
