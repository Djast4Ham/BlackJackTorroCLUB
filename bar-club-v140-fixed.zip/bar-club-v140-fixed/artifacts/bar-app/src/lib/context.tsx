import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from "react";
import { loadVkProfile, getLaunchParamsString } from "./vk.js";
import { api, setAuthToken, type ServerUser } from "./api.js";
import { trimMessages, formatTime } from "./utils.js";

export interface ChatMessage {
  id: string; author: string; text: string; time: string;
  reactions: Record<string, number>; isBot?: boolean;
}

export interface AppState {
  isLoggedIn: boolean;
  serverOnline: boolean;
  player: {
    name: string; id: string; vkUserId: number | null; avatarUrl?: string;
    isAdmin: boolean; balance: number; rating: number; stars: number;
    status: string; activeCard: string | null; gamesPlayed: number; joinDate: string;
  };
  chatMessages: ChatMessage[];
  adminLog: Array<{ time: string; action: string }>;
}

const defaultPlayer = {
  name: "Гость клуба", id: "#LOCAL", vkUserId: null, avatarUrl: undefined,
  isAdmin: false, balance: 1000, rating: 0, stars: 0,
  status: "PREMIUM", activeCard: "Diamond", gamesPlayed: 0, joinDate: "Май 2026",
};

const defaultState: AppState = {
  isLoggedIn: false,
  serverOnline: false,
  player: defaultPlayer,
  chatMessages: [
    { id: "1", author: "Система",   text: "Добро пожаловать в БАР Знакомств!", time: "00:00", reactions: {}, isBot: true },
    { id: "2", author: "Алексей_К", text: "Привет! Отличная атмосфера 👍",    time: "00:01", reactions: {} },
    { id: "3", author: "Мария_Р",   text: "Добрый вечер всем ✨",              time: "00:02", reactions: {} },
  ],
  adminLog: [{ time: "00:00", action: "Сервер запущен" }],
};

interface AppContextType {
  state: AppState;
  login: () => void;
  logout: () => void;
  updateBalance: (amount: number) => void;
  setBalance: (amount: number) => void;
  updateRating: (amount: number) => void;
  setActiveCard: (card: string) => void;
  sendMessage: (text: string) => void;
  sendBotMessage: (author: string, text: string) => void;
  addReaction: (messageId: string, emoji: string) => void;
  logAdminAction: (action: string) => void;
  applyServerUser: (user: ServerUser) => void;
}

const AppContext = createContext<AppContextType | null>(null);

function loadSavedState(): AppState {
  try {
    const raw = localStorage.getItem("barApp_state_v2");
    if (raw) {
      const s = JSON.parse(raw) as AppState;
      s.chatMessages = trimMessages(
        (s.chatMessages ?? []).map(m => ({ ...m, reactions: m.reactions ?? {} })),
        100,
      );
      s.serverOnline = false;
      return s;
    }
  } catch { /* ignore */ }
  return defaultState;
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(loadSavedState);
  const serverCheckRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Persist state (throttled)
  useEffect(() => {
    const trimmed = { ...state, chatMessages: trimMessages(state.chatMessages, 100) };
    localStorage.setItem("barApp_state_v2", JSON.stringify(trimmed));
  }, [state]);

  // Server health check
  const checkServer = useCallback(async () => {
    const online = await api.serverStatus();
    setState(s => s.serverOnline === online ? s : { ...s, serverOnline: online });
  }, []);

  useEffect(() => {
    checkServer();
    serverCheckRef.current = setInterval(checkServer, 30_000);
    return () => { if (serverCheckRef.current) clearInterval(serverCheckRef.current); };
  }, [checkServer]);

  // VK profile load + server auth attempt
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const vkProfile = await loadVkProfile();
      if (cancelled) return;

      setState(s => ({
        ...s,
        player: {
          ...s.player,
          name: vkProfile.name,
          id: vkProfile.id ? `VK ID ${vkProfile.id}` : s.player.id,
          vkUserId: vkProfile.id,
          avatarUrl: vkProfile.avatarUrl,
          isAdmin: false, // Will be set by server response
        },
      }));

      if (vkProfile.isVkRuntime) {
        const result = await api.loginVk(getLaunchParamsString());
        if (cancelled) return;
        if (result.ok) {
          setAuthToken(result.data.token);
          setState(s => ({
            ...s,
            serverOnline: true,
            player: {
              ...s.player,
              isAdmin:   result.data.user.isAdmin,
              balance:   result.data.user.balance,
              rating:    result.data.user.rating,
              stars:     result.data.user.stars,
              activeCard:result.data.user.activeCard,
              name:      result.data.user.name,
              avatarUrl: result.data.user.avatarUrl ?? s.player.avatarUrl,
            },
          }));
        }
      } else if (import.meta.env.DEV) {
        // Dev mode: grant admin locally
        setState(s => ({ ...s, player: { ...s.player, isAdmin: true } }));
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const now = () => formatTime(new Date());

  const login            = () => setState(s => ({ ...s, isLoggedIn: true }));
  const logout           = () => {
    setAuthToken(null);
    localStorage.removeItem("barApp_state_v2");
    setState({ ...defaultState });
  };
  const updateBalance    = (amount: number) => setState(s => ({ ...s, player: { ...s.player, balance: s.player.balance + amount } }));
  const setBalance       = (amount: number) => setState(s => ({ ...s, player: { ...s.player, balance: amount } }));
  const updateRating     = (amount: number) => setState(s => ({ ...s, player: { ...s.player, rating: amount } }));
  const setActiveCard    = (card: string)   => setState(s => ({ ...s, player: { ...s.player, activeCard: card } }));
  const applyServerUser  = (user: ServerUser) => setState(s => ({
    ...s,
    player: { ...s.player, balance: user.balance, rating: user.rating, stars: user.stars, activeCard: user.activeCard, isAdmin: user.isAdmin },
  }));

  const sendMessage = (text: string) => {
    const msg: ChatMessage = { id: Date.now().toString(), author: state.player.name, text, time: now(), reactions: {} };
    setState(s => ({ ...s, chatMessages: trimMessages([...s.chatMessages, msg], 100) }));
  };

  const sendBotMessage = (author: string, text: string) => {
    const msg: ChatMessage = { id: `${Date.now()}_bot`, author, text, time: now(), reactions: {}, isBot: true };
    setState(s => ({ ...s, chatMessages: trimMessages([...s.chatMessages, msg], 100) }));
  };

  const addReaction = (messageId: string, emoji: string) => {
    setState(s => ({
      ...s,
      chatMessages: s.chatMessages.map(m =>
        m.id === messageId ? { ...m, reactions: { ...m.reactions, [emoji]: (m.reactions[emoji] ?? 0) + 1 } } : m,
      ),
    }));
  };

  const logAdminAction = (action: string) => {
    setState(s => ({ ...s, adminLog: [{ time: now(), action }, ...s.adminLog.slice(0, 99)] }));
  };

  return (
    <AppContext.Provider value={{ state, login, logout, updateBalance, setBalance, updateRating, setActiveCard, sendMessage, sendBotMessage, addReaction, logAdminAction, applyServerUser }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
