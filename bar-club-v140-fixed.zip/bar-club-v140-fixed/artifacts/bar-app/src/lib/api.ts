const API_BASE = import.meta.env.VITE_API_URL ?? "/api";

let _token: string | null = null;

export function setAuthToken(token: string | null) { _token = token; }
export function getAuthToken(): string | null { return _token; }

async function apiFetch<T>(
  path: string,
  options: RequestInit = {},
): Promise<{ ok: true; data: T } | { ok: false; error: string }> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string> ?? {}),
  };
  if (_token) headers["Authorization"] = `Bearer ${_token}`;

  try {
    const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
    const json = await res.json().catch(() => ({})) as Record<string, unknown>;
    if (!res.ok) return { ok: false, error: String(json["error"] ?? "Ошибка сервера") };
    return { ok: true, data: json as T };
  } catch {
    return { ok: false, error: "Нет соединения с сервером" };
  }
}

export const api = {
  async serverStatus(): Promise<boolean> {
    try {
      const r = await fetch(`${API_BASE}/healthz`);
      return r.ok;
    } catch { return false; }
  },

  async loginVk(launchParams: string) {
    return apiFetch<{ token: string; user: ServerUser }>("/auth/vk", {
      method: "POST",
      body: JSON.stringify({ launchParams }),
    });
  },

  async getMessages() {
    return apiFetch<ServerMessage[]>("/messages");
  },

  async sendMessage(text: string) {
    return apiFetch<ServerMessage>("/messages", {
      method: "POST",
      body: JSON.stringify({ text }),
    });
  },

  async getProfile() {
    return apiFetch<ServerUser>("/profile");
  },

  async updateProfile(data: Partial<{ name: string; avatarUrl: string | null; activeCard: string }>) {
    return apiFetch<ServerUser>("/profile", { method: "PUT", body: JSON.stringify(data) });
  },

  async purchaseItem(itemId: string) {
    return apiFetch<{ balance: number; activeCard: string }>("/shop/purchase", {
      method: "POST",
      body: JSON.stringify({ itemId }),
    });
  },

  async dailyCheckin() {
    return apiFetch<{ streak: number; starsEarned: number; totalStars: number }>("/daily/checkin", { method: "POST" });
  },

  async dailyStatus() {
    return apiFetch<{ checkedToday: boolean; streak: number; last7: Array<{ date: string; stars: number }> }>("/daily/status");
  },

  async adminMute(targetVkId: number) {
    return apiFetch<{ ok: boolean; message: string }>("/admin/mute", { method: "POST", body: JSON.stringify({ targetVkId }) });
  },

  async adminUnmute(targetVkId: number) {
    return apiFetch<{ ok: boolean }>("/admin/unmute", { method: "POST", body: JSON.stringify({ targetVkId }) });
  },

  async adminBan(targetVkId: number) {
    return apiFetch<{ ok: boolean }>("/admin/ban", { method: "POST", body: JSON.stringify({ targetVkId }) });
  },

  async adminUnban(targetVkId: number) {
    return apiFetch<{ ok: boolean }>("/admin/unban", { method: "POST", body: JSON.stringify({ targetVkId }) });
  },

  async adminClearChat() {
    return apiFetch<{ ok: boolean }>("/admin/clear-chat", { method: "POST" });
  },

  async adminGrantBjt(targetVkId: number, amount: number) {
    return apiFetch<{ balance: number }>("/admin/grant-bjt", { method: "POST", body: JSON.stringify({ targetVkId, amount }) });
  },
};

export interface ServerUser {
  id: number; vkUserId: number; name: string; avatarUrl?: string;
  balance: number; rating: number; stars: number; activeCard: string;
  isAdmin: boolean; isBanned: boolean; isMuted: boolean; gamesPlayed: number;
}
export interface ServerMessage {
  id: number; userId: number; authorName: string; text: string;
  isBot: boolean; createdAt: string;
}
