export const VK_APP_ID    = Number(import.meta.env.VITE_VK_APP_ID ?? 54584981);
export const APP_VERSION  = "v1.0.40";

export interface VkUserProfile {
  id: number | null;
  name: string;
  avatarUrl?: string;
  isVkRuntime: boolean;
}

type VkBridgeLike = {
  send: (method: string, params?: Record<string, unknown>) => Promise<unknown>;
};
type VkUserInfoResponse = {
  id?: number; first_name?: string; last_name?: string;
  photo_100?: string; photo_200?: string;
};

declare global { interface Window { vkBridge?: VkBridgeLike; } }

function getSearchParams(): URLSearchParams {
  const hashQuery = window.location.hash.includes("?")
    ? window.location.hash.slice(window.location.hash.indexOf("?") + 1)
    : window.location.hash.replace(/^#/, "");
  const combined = new URLSearchParams(window.location.search);
  new URLSearchParams(hashQuery).forEach((v, k) => combined.set(k, v));
  return combined;
}

export function getLaunchParamsString(): string {
  return getSearchParams().toString();
}

export function isVkRuntime(): boolean {
  if (typeof window === "undefined") return false;
  const p = getSearchParams();
  return Boolean(p.get("vk_app_id") || p.get("vk_platform") || window.vkBridge);
}

export function getFallbackProfile(): VkUserProfile {
  const params = getSearchParams();
  const raw = params.get("vk_user_id") ?? params.get("viewer_id");
  const id = raw ? Number(raw) : NaN;
  const vkId = Number.isFinite(id) && id > 0 ? id : null;
  return {
    id: vkId,
    name: vkId ? `VK пользователь ${vkId}` : "Гость клуба",
    isVkRuntime: isVkRuntime(),
  };
}

export async function loadVkProfile(): Promise<VkUserProfile> {
  const fallback = getFallbackProfile();
  const bridge = typeof window !== "undefined" ? window.vkBridge : undefined;
  if (!bridge) return fallback;

  try {
    await bridge.send("VKWebAppInit");
    const data = (await bridge.send("VKWebAppGetUserInfo")) as VkUserInfoResponse;
    const id = typeof data.id === "number" ? data.id : fallback.id;
    const name = [data.first_name?.trim(), data.last_name?.trim()].filter(Boolean).join(" ") || fallback.name;
    return { id, name, avatarUrl: data.photo_200 || data.photo_100, isVkRuntime: true };
  } catch {
    return fallback;
  }
}
