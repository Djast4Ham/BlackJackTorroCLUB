import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { useApp } from '../lib/context';
import { APP_VERSION } from '../lib/vk';

export default function LoginScreen() {
  const { login } = useApp();
  const [, setLocation] = useLocation();

  const handleLogin = () => {
    login();
    setLocation('/dashboard');
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4 }}
      className="min-h-[100dvh] w-full flex flex-col items-center justify-center bg-[#0a0a0f] relative overflow-hidden"
      data-testid="screen-login"
    >
      {/* Card suits tiled background */}
      <div className="suits-pattern" />

      {/* Ambient glow layers */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full"
          style={{ background: 'radial-gradient(circle, rgba(201,168,76,0.07) 0%, transparent 65%)' }}
        />
        <div
          className="absolute bottom-0 left-0 w-full h-64"
          style={{ background: 'radial-gradient(ellipse at bottom, rgba(107,30,42,0.1) 0%, transparent 70%)' }}
        />
      </div>

      {/* Main content */}
      <motion.div
        initial={{ opacity: 0, y: 32 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: 'easeOut' }}
        className="flex flex-col items-center gap-7 px-6 max-w-md w-full text-center relative z-10"
      >
        {/* Title block */}
        <div className="space-y-1">
          <motion.h1
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.7 }}
            className="font-serif text-6xl font-bold gold-gradient-text leading-none tracking-tight"
          >
            БАР
          </motion.h1>
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            className="font-serif text-2xl font-medium text-foreground/75 tracking-[0.25em] uppercase"
          >
            Знакомств
          </motion.h2>
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="flex items-center justify-center gap-3 mt-2"
          >
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-primary/50" />
            <span className="text-primary font-serif text-xl">!</span>
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-primary/50" />
          </motion.div>
        </div>

        {/* Login card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="ornament-card relative w-full rounded-2xl p-8 flex flex-col items-center gap-5"
          style={{
            background: 'linear-gradient(160deg, #18161f, #12101a)',
            border: '1px solid rgba(201,168,76,0.25)',
            boxShadow: '0 0 60px rgba(201,168,76,0.07), 0 8px 40px rgba(0,0,0,0.6), inset 0 1px 0 rgba(201,168,76,0.12)',
          }}
        >
          {/* Corner ornaments */}
          <div className="absolute top-3 left-3 text-primary/20 text-xs font-serif leading-none select-none">♠ ♦</div>
          <div className="absolute top-3 right-3 text-primary/20 text-xs font-serif leading-none select-none">♥ ♣</div>
          <div className="absolute bottom-3 left-3 text-primary/20 text-xs font-serif leading-none select-none">♣ ♥</div>
          <div className="absolute bottom-3 right-3 text-primary/20 text-xs font-serif leading-none select-none">♦ ♠</div>

          <div className="text-center space-y-1 pt-1">
            <p className="text-foreground/70 text-sm tracking-wide">Добро пожаловать в закрытый клуб</p>
            <p className="text-muted-foreground/50 text-xs">Вход только для членов клуба</p>
          </div>

          {/* Divider with suits */}
          <div className="flex items-center gap-2 w-full">
            <div className="h-px flex-1 bg-primary/15" />
            <span className="text-primary/30 text-xs tracking-widest font-serif">♠ ♦ ♣ ♥</span>
            <div className="h-px flex-1 bg-primary/15" />
          </div>

          <motion.button
            whileHover={{ scale: 1.025, boxShadow: '0 0 45px rgba(201,168,76,0.55), 0 4px 20px rgba(0,0,0,0.4)' }}
            whileTap={{ scale: 0.975 }}
            onClick={handleLogin}
            data-testid="button-login"
            className="w-full h-14 rounded-xl font-serif text-lg font-bold tracking-[0.15em] text-[#0a0a0f] relative overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, #b8922a, #f0d080 40%, #e8c45a 60%, #b8922a)',
              boxShadow: '0 0 30px rgba(201,168,76,0.4), 0 4px 15px rgba(0,0,0,0.4)',
            }}
          >
            <span className="relative z-10">ВОЙТИ В БАР</span>
            <motion.div
              className="absolute inset-0 bg-white/10"
              initial={{ x: '-100%', skewX: '-20deg' }}
              whileHover={{ x: '200%' }}
              transition={{ duration: 0.5 }}
            />
          </motion.button>

          <p className="text-muted-foreground/40 text-xs pb-1">
            Только для зарегистрированных участников
          </p>
        </motion.div>

        {/* Version */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="text-muted-foreground/30 text-xs tracking-[0.3em]"
          data-testid="text-version"
        >
          {APP_VERSION}
        </motion.p>
      </motion.div>
    </motion.div>
  );
}
