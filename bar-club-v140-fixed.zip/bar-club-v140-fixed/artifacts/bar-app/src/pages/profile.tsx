import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Coins, Star, Gamepad2, Calendar, ShoppingBag, Sparkles } from "lucide-react";
import { useApp } from "../lib/context.js";
import { useToast } from "../hooks/use-toast.js";
import { getInitials } from "../lib/utils.js";
import { api } from "../lib/api.js";

const CARD_STYLES: Record<string, { gradient: string; border: string; glow: string; accent: string; label: string; symbol: string }> = {
  Diamond: { gradient: "linear-gradient(135deg, #0c1a2e, #0e3460)", border: "#38bdf8", glow: "rgba(56,189,248,0.4)",   accent: "#7dd3fc", label: "Diamond PREMIUM",  symbol: "◈" },
  Platinum:{ gradient: "linear-gradient(135deg, #1e293b, #334155)", border: "#94a3b8", glow: "rgba(148,163,184,0.3)", accent: "#e2e8f0", label: "Platinum PREMIUM", symbol: "★" },
  Ruby:    { gradient: "linear-gradient(135deg, #4c0519, #881337)", border: "#e11d48", glow: "rgba(225,29,72,0.4)",   accent: "#fb7185", label: "Ruby PREMIUM",     symbol: "♦" },
  Cosmos:  { gradient: "linear-gradient(135deg, #1e1b4b, #312e81)", border: "#6d28d9", glow: "rgba(109,40,217,0.4)", accent: "#a78bfa", label: "Cosmos PREMIUM",   symbol: "✦" },
};

export default function PlayerProfile() {
  const { state, applyServerUser } = useApp();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { player } = state;

  const cardKey   = player.activeCard ?? "Diamond";
  const cardStyle = CARD_STYLES[cardKey] ?? CARD_STYLES["Diamond"];
  const initials  = getInitials(player.name);

  const handleDailyCheckin = async () => {
    const result = await api.dailyCheckin();
    if (!result.ok) {
      toast({ title: result.error, variant: "destructive" });
      return;
    }
    const { starsEarned, streak, totalStars } = result.data;
    toast({
      title: `+${starsEarned} звёзд!`,
      description: `Серия: ${streak} дней · Всего звёзд: ${totalStars}`,
      className: "border-primary bg-card text-primary",
    });
    const profile = await api.getProfile();
    if (profile.ok) applyServerUser(profile.data);
  };

  const stats = [
    { label: "БАЛАНС",   value: `${player.balance.toLocaleString("ru-RU")} BJT`, icon: Coins,    testid: "stat-balance" },
    { label: "РЕЙТИНГ",  value: String(player.rating),                            icon: Star,     testid: "stat-rating"  },
    { label: "ВСТРЕЧИ",  value: String(player.gamesPlayed),                       icon: Gamepad2, testid: "stat-games"   },
    { label: "В БАРЕ С", value: player.joinDate,                                  icon: Calendar, testid: "stat-joined"  },
  ];

  return (
    <div className="min-h-[100dvh] flex flex-col items-center bg-[#0a0a0f] px-4 py-6 gap-5">
      <div className="w-full max-w-lg flex items-center justify-between">
        <h1 className="font-serif text-xl gold-gradient-text font-bold">МОЙ ПРОФИЛЬ</h1>
        {player.stars > 0 && (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full"
            style={{ background: "rgba(201,168,76,0.1)", border: "1px solid rgba(201,168,76,0.25)" }}>
            <Sparkles size={12} className="text-primary" />
            <span className="text-xs font-semibold gold-gradient-text">{player.stars} звёзд</span>
          </div>
        )}
      </div>

      <motion.div
        initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.05 }}
        className="w-full max-w-lg rounded-2xl border border-primary/30 overflow-hidden"
        style={{ boxShadow: "0 0 40px rgba(201,168,76,0.1), 0 4px 30px rgba(0,0,0,0.5)" }}
      >
        <div className="p-6 flex flex-col items-center gap-4" style={{ background: "linear-gradient(180deg, #1a1825, #12111a)" }}>
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1, type: "spring", stiffness: 160 }}
            className="w-24 h-24 rounded-full flex items-center justify-center text-3xl font-serif font-bold select-none overflow-hidden"
            style={{ background: "radial-gradient(circle at 40% 35%, #2a2020, #0a0a0f)", border: "3px solid rgba(201,168,76,0.6)", boxShadow: "0 0 25px rgba(201,168,76,0.3)", color: "#f0d080" }}
            data-testid="avatar-player"
          >
            {player.avatarUrl
              ? <img src={player.avatarUrl} alt={player.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              : initials}
          </motion.div>
          <div className="text-center">
            <h2 className="font-serif text-2xl font-bold gold-gradient-text" data-testid="text-profile-name">{player.name}</h2>
            <p className="text-muted-foreground text-sm mt-0.5" data-testid="text-profile-id">{player.id}</p>
          </div>
          <div className="px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider flex items-center gap-2"
            style={{ background: cardStyle.border + "20", border: `1px solid ${cardStyle.border}`, color: cardStyle.accent, boxShadow: `0 0 15px ${cardStyle.glow}` }}
            data-testid="badge-card">
            <span>{cardStyle.symbol}</span>{cardStyle.label}
          </div>
        </div>

        <div className="border-t border-primary/15 grid grid-cols-2" data-testid="stats-grid">
          {stats.map(({ label, value, icon: Icon, testid }, i) => (
            <div key={label} className="p-4 flex flex-col gap-1.5 bg-card/40"
              style={{ borderRight: i % 2 === 0 ? "1px solid rgba(201,168,76,0.1)" : "none", borderBottom: i < 2 ? "1px solid rgba(201,168,76,0.1)" : "none" }}
              data-testid={testid}>
              <div className="flex items-center gap-1.5">
                <Icon size={13} className="text-primary/70" />
                <span className="text-muted-foreground text-[10px] tracking-wider">{label}</span>
              </div>
              <span className="font-serif text-base font-semibold text-foreground">{value}</span>
            </div>
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ y: 16, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.15 }}
        className="w-full max-w-lg"
      >
        <p className="text-muted-foreground/60 text-xs tracking-wider mb-2 uppercase">Активная карта</p>
        <div className="rounded-xl p-4 flex items-center gap-4"
          style={{ background: cardStyle.gradient, border: `1px solid ${cardStyle.border}50`, boxShadow: `0 0 20px ${cardStyle.glow}` }}>
          <div className="w-12 h-12 rounded-lg flex items-center justify-center text-2xl font-serif shrink-0"
            style={{ background: cardStyle.border + "20", color: cardStyle.accent, border: `1px solid ${cardStyle.border}30` }}>
            {cardStyle.symbol}
          </div>
          <div>
            <p className="font-serif font-semibold" style={{ color: cardStyle.accent }}>{cardStyle.label}</p>
            <p className="text-muted-foreground text-xs">Текущий тир</p>
          </div>
          <div className="ml-auto">
            <span className="text-[10px] px-2 py-0.5 rounded-full font-bold tracking-wider"
              style={{ background: cardStyle.border + "20", border: `1px solid ${cardStyle.border}50`, color: cardStyle.accent }}>
              АКТИВНО
            </span>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ y: 16, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }}
        className="w-full max-w-lg grid grid-cols-2 gap-3"
      >
        <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}
          onClick={() => setLocation("/shop")} data-testid="button-change-card"
          className="flex items-center justify-center gap-2 py-3.5 rounded-xl border border-primary/25 bg-card/50 hover:border-primary/60 hover:bg-card transition-all text-sm font-medium text-foreground/75 hover:text-primary">
          <ShoppingBag size={16} className="text-primary" /> Изменить карту
        </motion.button>
        <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}
          onClick={handleDailyCheckin} data-testid="button-daily-checkin"
          className="flex items-center justify-center gap-2 py-3.5 rounded-xl border border-primary/25 bg-primary/10 hover:border-primary/60 hover:bg-primary/20 transition-all text-sm font-medium"
          style={{ color: "#f0d080" }}>
          <Sparkles size={16} className="text-primary" /> Ежедневный вход
        </motion.button>
      </motion.div>
    </div>
  );
}
