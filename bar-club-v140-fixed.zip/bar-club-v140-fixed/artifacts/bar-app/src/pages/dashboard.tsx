import { useEffect, useRef, useState } from 'react';
import { useLocation } from 'wouter';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { Coins, Star, Wifi, Wine, ShoppingBag, User } from 'lucide-react';
import { useApp } from '../lib/context';
import { APP_VERSION } from '../lib/vk';

/* Animated number with spring */
function AnimatedNumber({ value, suffix = '' }: { value: number; suffix?: string }) {
  const mv = useMotionValue(value);
  const spring = useSpring(mv, { stiffness: 70, damping: 16, restDelta: 0.5 });
  const display = useTransform(spring, v => `${Math.round(v).toLocaleString('ru-RU')}${suffix}`);

  const prevRef = useRef(value);
  useEffect(() => {
    if (prevRef.current !== value) {
      mv.set(value);
      prevRef.current = value;
    }
  }, [value, mv]);

  // Set initial value immediately on mount
  useEffect(() => { mv.set(value); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return <motion.span>{display}</motion.span>;
}

const CARD_GLOW: Record<string, string> = {
  Diamond: 'rgba(125,211,252,0.2)',
  Platinum:'rgba(203,213,225,0.18)',
  Ruby:    'rgba(225,29,72,0.22)',
  Cosmos:  'rgba(139,92,246,0.22)',
};
const CARD_OVERLAY: Record<string, string> = {
  Diamond: 'linear-gradient(135deg, rgba(56,189,248,0.07), rgba(14,52,96,0.1))',
  Platinum:'linear-gradient(135deg, rgba(148,163,184,0.06), rgba(30,41,59,0.08))',
  Ruby:    'linear-gradient(135deg, rgba(225,29,72,0.08), rgba(76,5,25,0.1))',
  Cosmos:  'linear-gradient(135deg, rgba(109,40,217,0.08), rgba(30,27,75,0.1))',
};

export default function Dashboard() {
  const { state } = useApp();
  const [, setLocation] = useLocation();
  const { player } = state;
  const active = player.activeCard ?? 'Diamond';

  // Flash animation on balance change
  const prevBalRef = useRef(player.balance);
  const [flash, setFlash] = useState<'up' | 'down' | null>(null);
  useEffect(() => {
    if (player.balance === prevBalRef.current) return;
    setFlash(player.balance > prevBalRef.current ? 'up' : 'down');
    prevBalRef.current = player.balance;
    const t = setTimeout(() => setFlash(null), 1200);
    return () => clearTimeout(t);
  }, [player.balance]);

  return (
    <div className="min-h-[100dvh] flex flex-col items-center bg-[#0a0a0f] px-4 py-6 gap-5" data-testid="screen-dashboard">
      {/* Header */}
      <div className="w-full max-w-lg flex items-center justify-between">
        <div>
          <h1 className="font-serif text-2xl gold-gradient-text font-bold leading-tight">БАР Знакомств!</h1>
          <p className="text-muted-foreground text-xs tracking-widest">{APP_VERSION}</p>
        </div>
        <motion.div
          animate={{ opacity: [1, 0.5, 1] }}
          transition={{ duration: 2.2, repeat: Infinity }}
          className="flex items-center gap-1.5 rounded-full border border-green-400/20 bg-green-400/5 px-2 py-1"
        >
          <span className="w-2 h-2 rounded-full bg-green-400" style={{ boxShadow: '0 0 7px rgba(74,222,128,0.9)' }} />
          <span className="text-green-400 text-[10px] uppercase tracking-wider" data-testid="status-server">online</span>
        </motion.div>
      </div>

      {/* Player card */}
      <motion.div
        initial={{ y: 18, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.08 }}
        className="w-full max-w-lg rounded-2xl border border-primary/30 p-6 relative overflow-hidden"
        style={{
          background: 'linear-gradient(145deg, #14121c, #1c1928)',
          boxShadow: `0 0 50px ${CARD_GLOW[active] ?? CARD_GLOW['Diamond']}, 0 6px 30px rgba(0,0,0,0.6)`,
        }}
      >
        <div className="absolute inset-0 pointer-events-none rounded-2xl"
          style={{ background: CARD_OVERLAY[active] ?? CARD_OVERLAY['Diamond'] }} />

        <div className="relative z-10 flex flex-col gap-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-muted-foreground/60 text-xs tracking-wider mb-1">УЧАСТНИК</p>
              <p className="font-serif text-xl font-semibold text-foreground" data-testid="text-playername">{player.name}</p>
              <p className="text-muted-foreground text-xs">{player.id}</p>
            </div>
            <div
              className="px-3 py-1 rounded-full border border-primary/50 text-xs font-bold tracking-widest gold-gradient-text"
              style={{ boxShadow: '0 0 14px rgba(201,168,76,0.28)' }}
              data-testid="badge-status"
            >
              {player.status}
            </div>
          </div>

          <div className="h-px bg-gradient-to-r from-transparent via-primary/25 to-transparent" />

          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-1">
              <p className="text-muted-foreground/60 text-xs tracking-wider">БАЛАНС</p>
              <div className="flex items-center gap-2">
                <Coins size={20} className="text-primary shrink-0" />
                <span
                  className="font-serif text-3xl font-bold gold-gradient-text"
                  style={{
                    filter: flash === 'up' ? 'drop-shadow(0 0 8px #4ade80)' : flash === 'down' ? 'drop-shadow(0 0 8px #f87171)' : 'none',
                    transition: 'filter 0.4s ease',
                  }}
                  data-testid="text-balance"
                >
                  <AnimatedNumber value={player.balance} suffix=" BJT" />
                </span>
              </div>
            </div>
            <div className="flex flex-col gap-1 items-end">
              <p className="text-muted-foreground/60 text-xs tracking-wider">РЕЙТИНГ</p>
              <div className="flex items-center gap-2">
                <Star size={18} className="text-primary" />
                <span className="font-serif text-2xl font-bold text-foreground" data-testid="text-rating">
                  <AnimatedNumber value={player.rating} />
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="h-px flex-1 bg-primary/15" />
            <span className="text-primary/40 text-xs tracking-widest uppercase">{active} Card</span>
            <div className="h-px flex-1 bg-primary/15" />
          </div>
        </div>
      </motion.div>

      {/* Quick actions */}
      <div className="w-full max-w-lg grid grid-cols-3 gap-3">
        {[
          { label: 'В БАР',   icon: Wine,        href: '/bar',     testid: 'button-goto-bar' },
          { label: 'МАГАЗИН', icon: ShoppingBag, href: '/shop',    testid: 'button-goto-shop' },
          { label: 'ПРОФИЛЬ', icon: User,        href: '/profile', testid: 'button-goto-profile' },
        ].map(({ label, icon: Icon, href, testid }) => (
          <motion.button
            key={href}
            whileHover={{ scale: 1.04, boxShadow: '0 0 20px rgba(201,168,76,0.14)' }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setLocation(href)}
            data-testid={testid}
            className="flex flex-col items-center gap-2 py-4 rounded-xl border border-primary/20 bg-card/60 hover:border-primary/50 transition-all group"
          >
            <Icon size={22} className="text-primary transition-transform group-hover:scale-110" />
            <span className="text-xs font-semibold tracking-wider text-muted-foreground group-hover:text-primary transition-colors">{label}</span>
          </motion.button>
        ))}
      </div>

      {/* Stats */}
      <div className="w-full max-w-lg grid grid-cols-2 gap-3">
        <div className="rounded-xl border border-primary/15 bg-card/50 p-4 flex flex-col gap-1">
          <p className="text-muted-foreground/60 text-xs tracking-wider">ВСТРЕЧИ</p>
          <p className="font-serif text-xl font-bold text-foreground" data-testid="text-games">
            <AnimatedNumber value={player.gamesPlayed} />
          </p>
        </div>
        <div className="rounded-xl border border-primary/15 bg-card/50 p-4 flex flex-col gap-1">
          <p className="text-muted-foreground/60 text-xs tracking-wider">В БАРЕ С</p>
          <p className="font-serif text-xl font-bold text-foreground">{player.joinDate}</p>
        </div>
      </div>

      {/* Online */}
      <div className="w-full max-w-lg rounded-xl border border-green-500/20 bg-green-500/5 p-4 flex items-center gap-3">
        <Wifi size={18} className="text-green-400 shrink-0" />
        <div>
          <p className="text-green-400 text-sm font-medium">Соединение установлено</p>
          <p className="text-muted-foreground text-xs">Бар активен · 11 участников онлайн</p>
        </div>
      </div>
    </div>
  );
}
