import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Home, AlertCircle } from "lucide-react";

export default function NotFound() {
  const [, setLocation] = useLocation();
  return (
    <div className="min-h-[100dvh] flex flex-col items-center justify-center bg-[#0a0a0f] px-4 gap-6">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col items-center gap-5 text-center max-w-sm"
      >
        <div
          className="w-20 h-20 rounded-2xl flex items-center justify-center"
          style={{ background: "rgba(225,29,72,0.1)", border: "1px solid rgba(225,29,72,0.3)" }}
        >
          <AlertCircle size={36} style={{ color: "#fb7185" }} />
        </div>
        <div className="space-y-2">
          <h1 className="font-serif text-5xl font-bold" style={{ color: "rgba(201,168,76,0.4)" }}>404</h1>
          <p className="font-serif text-xl text-foreground/70">Страница не найдена</p>
          <p className="text-muted-foreground text-sm">Возможно, вы попали не туда. Вернитесь на главную.</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.04, boxShadow: "0 0 20px rgba(201,168,76,0.25)" }}
          whileTap={{ scale: 0.96 }}
          onClick={() => setLocation("/dashboard")}
          className="flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold tracking-wide"
          style={{
            background: "linear-gradient(135deg, #b8922a, #f0d080 50%, #b8922a)",
            color: "#0a0a0f",
            boxShadow: "0 0 20px rgba(201,168,76,0.25)",
          }}
        >
          <Home size={16} />
          На главную
        </motion.button>
      </motion.div>
    </div>
  );
}
