import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Users, X, Bot } from "lucide-react";
import { useApp } from "../lib/context.js";
import { getInitials } from "../lib/utils.js";

const SEATS = [
  { name: "Гость клуба", active: true,  initials: "ГК", color: "#c9a84c", card: "Diamond",  status: "PREMIUM" },
  { name: "Алексей_К",   active: true,  initials: "АК", color: "#7c3aed", card: "Cosmos",   status: "VIP"     },
  { name: "Мария_Р",     active: true,  initials: "МР", color: "#db2777", card: "Ruby",     status: "PREMIUM" },
  { name: "Виктор_П",    active: true,  initials: "ВП", color: "#0891b2", card: "Diamond",  status: "VIP"     },
  { name: "Анна_С",      active: true,  initials: "АС", color: "#059669", card: "Platinum", status: "PREMIUM" },
  { name: "Денис_Ф",     active: true,  initials: "ДФ", color: "#d97706", card: "Ruby",     status: "VIP"     },
  { name: "Ольга_М",     active: true,  initials: "ОМ", color: "#7c3aed", card: "Cosmos",   status: "PREMIUM" },
  { name: "Иван_Н",      active: true,  initials: "ИН", color: "#0e7490", card: "Platinum", status: "VIP"     },
  { name: "Катя_Д",      active: true,  initials: "КД", color: "#be185d", card: "Diamond",  status: "PREMIUM" },
  { name: "Роман_Т",     active: true,  initials: "РТ", color: "#15803d", card: "Ruby",     status: "VIP"     },
  { name: "Света_Ж",     active: true,  initials: "СЖ", color: "#b45309", card: "Cosmos",   status: "PREMIUM" },
  { name: "",            active: false, initials: "",   color: "#333",    card: "",         status: ""        },
];

const BOT_POOL = [
  { author: "Алексей_К",  msgs: ["Отличная атмосфера! 😄", "Кто за новый тост? 🔥"] },
  { author: "Мария_Р",    msgs: ["Всем хорошего вечера ✨", "Красивый стиль!"] },
  { author: "Виктор_П",   msgs: ["Хороший выбор 👍", "Как настроение? 😏"] },
  { author: "Анна_С",     msgs: ["Жду своего часа", "Отличная атмосфера ❤️"] },
];

const EMOJI_CATS = [
  { label: "Часто",   emojis: ["👍","❤️","😊","🔥","😂","🎉","🙏","💯"] },
  { label: "Бар",     emojis: ["🃏","🎰","♠️","♥️","♣️","♦️","🍷","💎"] },
  { label: "Эмоции",  emojis: ["😄","😎","🤩","😏","😤","🤔","😮","🥳"] },
  { label: "Символы", emojis: ["✨","⚡","💥","🌟","👑","🏆","🎯","💰"] },
];
const QUICK = ["👍","❤️","😂","🔥","💎","🎉"];
const MAX_MSG_LEN = 280;

function SeatTooltip({ seat, onClose }: { seat: typeof SEATS[0]; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.82, y: 6 }} animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.82, y: 6 }} transition={{ duration: 0.15 }}
      className="absolute z-50 w-40 rounded-xl p-3 flex flex-col gap-2"
      style={{ background: "linear-gradient(145deg, #1c1a2a, #141220)", border: `1px solid ${seat.color}55`,
        boxShadow: `0 8px 32px rgba(0,0,0,0.75), 0 0 16px ${seat.color}22`,
        bottom: "calc(100% + 8px)", left: "50%", transform: "translateX(-50%)", pointerEvents: "auto" }}
    >
      <button onClick={onClose} className="absolute top-1.5 right-1.5 text-muted-foreground/40 hover:text-foreground/60 leading-none"><X size={10} /></button>
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 text-[#0a0a0f]" style={{ background: seat.color }}>{seat.initials}</div>
        <div className="min-w-0">
          <p className="text-foreground text-xs font-semibold truncate">{seat.name}</p>
          <p className="text-muted-foreground/60 text-[9px]">{seat.card} · {seat.status}</p>
        </div>
      </div>
      <div className="h-px bg-primary/15" />
      <div className="flex items-center gap-1.5">
        <span className="w-1.5 h-1.5 rounded-full bg-green-400 shrink-0" />
        <span className="text-green-400 text-[9px]">в сети</span>
      </div>
    </motion.div>
  );
}

function PlayerSeat({ seat, index, total, radius }: { seat: typeof SEATS[0]; index: number; total: number; radius: number }) {
  const [tipOpen, setTipOpen] = useState(false);
  const angle = (index / total) * 2 * Math.PI - Math.PI / 2;
  const x = Math.cos(angle) * radius;
  const y = Math.sin(angle) * radius;
  return (
    <div className="absolute flex flex-col items-center gap-1"
      style={{ left: `calc(50% + ${x}px)`, top: `calc(50% + ${y}px)`, transform: "translate(-50%,-50%)", width: 64 }}
      data-testid={`seat-player-${index}`}>
      <div className="relative">
        <motion.div
          animate={seat.active ? { boxShadow: [`0 0 7px ${seat.color}44`, `0 0 18px ${seat.color}88`, `0 0 7px ${seat.color}44`] } : {}}
          transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut", delay: (index * 0.22) % 2.4 }}
          onClick={() => seat.active && setTipOpen(v => !v)}
          className="w-11 h-11 rounded-full flex items-center justify-center text-xs font-bold text-white"
          style={{ cursor: seat.active ? "pointer" : "default",
            background: seat.active ? `radial-gradient(circle at 35% 35%, ${seat.color}dd, ${seat.color}88)` : "#1a1828",
            border: seat.active ? `2px solid ${seat.color}` : "2px solid #2a2838" }}
        >
          {seat.active ? seat.initials : ""}
          {seat.active && (
            <motion.span animate={{ opacity: [1, 0.5, 1] }} transition={{ duration: 1.8, repeat: Infinity, delay: index * 0.15 }}
              className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-green-400 border-2 border-[#0a0a0f]"
              style={{ boxShadow: "0 0 6px rgba(74,222,128,0.9)" }} />
          )}
        </motion.div>
        <AnimatePresence>{tipOpen && seat.active && <SeatTooltip seat={seat} onClose={() => setTipOpen(false)} />}</AnimatePresence>
      </div>
      {seat.name ? <span className="text-[8.5px] text-center leading-tight text-muted-foreground/60 truncate w-full text-center">{seat.name}</span>
                 : <span className="text-[9px] text-muted-foreground/25">пусто</span>}
    </div>
  );
}

function EmojiPicker({ onSelect, onClose }: { onSelect: (e: string) => void; onClose: () => void }) {
  const [tab, setTab] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) onClose(); };
    setTimeout(() => document.addEventListener("mousedown", h), 0);
    return () => document.removeEventListener("mousedown", h);
  }, [onClose]);
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 6, scale: 0.94 }} animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 6, scale: 0.94 }} transition={{ duration: 0.14 }}
      className="absolute bottom-full mb-2 left-0 w-56 rounded-xl overflow-hidden z-50"
      style={{ background: "linear-gradient(145deg, #1a1828, #111020)", border: "1px solid rgba(201,168,76,0.2)", boxShadow: "0 -4px 40px rgba(0,0,0,0.8)" }}>
      <div className="flex border-b border-primary/15">
        {EMOJI_CATS.map((cat, i) => (
          <button key={cat.label} onClick={() => setTab(i)} className="flex-1 py-2 text-[9px] font-medium transition-colors"
            style={{ color: tab === i ? "#f0d080" : "rgba(160,144,128,0.5)", borderBottom: tab === i ? "2px solid #f0d080" : "2px solid transparent" }}>
            {cat.label}
          </button>
        ))}
      </div>
      <div className="p-2 grid grid-cols-8 gap-0.5">
        {EMOJI_CATS[tab].emojis.map(e => (
          <button key={e} onClick={() => onSelect(e)} className="text-base p-1 rounded hover:bg-primary/15 transition-colors leading-none">{e}</button>
        ))}
      </div>
    </motion.div>
  );
}

function MessageRow({ msg, isOwn, onReact }: {
  msg: { id: string; author: string; text: string; time: string; reactions: Record<string, number>; isBot?: boolean };
  isOwn: boolean; onReact: (id: string, emoji: string) => void;
}) {
  const [hovered, setHovered] = useState(false);
  return (
    <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.18 }}
      className="flex flex-col gap-0.5" onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}>
      <div className="flex items-center gap-1.5 flex-wrap">
        <span className={`text-[10px] font-semibold ${isOwn ? "text-primary" : "text-foreground/65"}`}>{msg.author}</span>
        {msg.isBot && (
          <span className="flex items-center gap-0.5 text-[8px] px-1 py-0.5 rounded" style={{ background: "rgba(107,114,128,0.2)", color: "rgba(156,163,175,0.7)" }}>
            <Bot size={7} /> бот
          </span>
        )}
        <span className="text-muted-foreground/30 text-[9px]">{msg.time}</span>
      </div>
      <div className="relative">
        <p className="text-[13px] leading-relaxed break-words px-0.5 py-0.5"
          style={{ color: isOwn ? "rgba(240,208,128,0.95)" : "rgba(255,255,255,0.84)", textShadow: isOwn ? "0 0 10px rgba(201,168,76,0.12)" : "none" }}>
          {msg.text}
        </p>
        <AnimatePresence>
          {hovered && (
            <motion.div initial={{ opacity: 0, scale: 0.85, y: 2 }} animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.85 }} transition={{ duration: 0.1 }}
              className="absolute -top-7 right-0 flex gap-0.5 rounded-lg px-1.5 py-1 z-10"
              style={{ background: "rgba(18,16,26,0.97)", border: "1px solid rgba(201,168,76,0.18)", boxShadow: "0 4px 16px rgba(0,0,0,0.6)" }}>
              {QUICK.map(e => (
                <button key={e} onClick={() => onReact(msg.id, e)} className="text-sm hover:scale-125 transition-transform leading-none">{e}</button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      {Object.keys(msg.reactions).length > 0 && (
        <div className="flex flex-wrap gap-1 mt-0.5">
          {Object.entries(msg.reactions).map(([emoji, count]) => (
            <motion.button key={emoji} initial={{ scale: 0 }} animate={{ scale: 1 }}
              onClick={() => onReact(msg.id, emoji)}
              className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] transition-all hover:bg-primary/20"
              style={{ background: "rgba(201,168,76,0.08)", border: "0", color: "#c9a84c" }}>
              <span>{emoji}</span><span>{count}</span>
            </motion.button>
          ))}
        </div>
      )}
    </motion.div>
  );
}

export default function BarRoom() {
  const { state, sendMessage, sendBotMessage, addReaction } = useApp();
  const dynamicSeats = SEATS.map((seat, i) => i === 0
    ? { ...seat, name: state.player.name, initials: getInitials(state.player.name), card: state.player.activeCard ?? "Diamond", status: state.player.status }
    : seat,
  );

  const [input, setInput]       = useState("");
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [isTyping, setIsTyping]  = useState(false);
  const messagesEndRef           = useRef<HTMLDivElement>(null);
  const typingTimerRef           = useRef<ReturnType<typeof setTimeout> | null>(null);
  const sendBotRef               = useRef(sendBotMessage);
  useEffect(() => { sendBotRef.current = sendBotMessage; }, [sendBotMessage]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [state.chatMessages]);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const schedule = () => {
      const delay = 25000 + Math.random() * 30000;
      timer = setTimeout(() => {
        const bot = BOT_POOL[Math.floor(Math.random() * BOT_POOL.length)];
        sendBotRef.current(bot.author, bot.msgs[Math.floor(Math.random() * bot.msgs.length)]);
        schedule();
      }, delay);
    };
    schedule();
    return () => clearTimeout(timer);
  }, []);

  const remaining = MAX_MSG_LEN - input.length;

  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value.length > MAX_MSG_LEN) return;
    setInput(e.target.value);
    setIsTyping(true);
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
    typingTimerRef.current = setTimeout(() => setIsTyping(false), 1500);
  };

  const handleSend = () => {
    const text = input.trim();
    if (!text || text.length > MAX_MSG_LEN) return;
    sendMessage(text);
    setInput(""); setIsTyping(false); setEmojiOpen(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  return (
    <div className="flex flex-col bg-[#0a0a0f]" style={{ height: "calc(100dvh - 4rem)" }} data-testid="screen-bar">
      <div className="px-4 py-3 border-b border-primary/15 flex items-center justify-between shrink-0">
        <h2 className="font-serif text-lg gold-gradient-text font-bold tracking-wide">БАР ЗНАКОМСТВ</h2>
        <div className="flex items-center gap-1.5">
          <motion.div animate={{ opacity: [1, 0.4, 1] }} transition={{ duration: 2, repeat: Infinity }}
            className="w-1.5 h-1.5 rounded-full bg-green-400" style={{ boxShadow: "0 0 5px rgba(74,222,128,0.8)" }} />
          <Users size={13} className="text-green-400" />
          <span className="text-green-400 text-xs font-medium" data-testid="text-online">
            {state.serverOnline ? "Сервер активен" : "Превью-режим"}
          </span>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden min-h-0 max-sm:flex-col">
        {/* Table */}
        <div className="flex-1 flex items-center justify-center overflow-hidden p-2 max-sm:min-h-[290px]">
          <div className="relative" style={{ width: 300, height: 300, flexShrink: 0 }}>
            <div className="absolute inset-0 rounded-full pointer-events-none"
              style={{ boxShadow: "0 0 60px rgba(107,61,30,0.35), 0 0 100px rgba(107,61,30,0.15)" }} />
            <div className="absolute inset-0 rounded-full flex items-center justify-center"
              style={{ background: "radial-gradient(circle at 38% 32%, #4a2812 0%, #2a1508 45%, #150a03 100%)",
                border: "4px solid #7a4520", boxShadow: "0 0 0 1px #5a3010, inset 0 4px 20px rgba(0,0,0,0.7)" }}>
              <div className="absolute rounded-full" style={{ inset: 20, border: "2px solid #3a5a3a44" }} />
              <div className="w-32 h-32 rounded-full flex items-center justify-center flex-col gap-1"
                style={{ background: "radial-gradient(circle at 38% 32%, #1e401e, #0e240e)", border: "2px solid rgba(45,74,45,0.6)", boxShadow: "inset 0 3px 15px rgba(0,0,0,0.8)" }}>
                <span className="text-3xl font-serif" style={{ color: "rgba(201,168,76,0.35)", textShadow: "0 0 10px rgba(201,168,76,0.2)" }}>♠</span>
                <span className="text-[9px] tracking-[0.3em] font-serif" style={{ color: "rgba(201,168,76,0.25)" }}>БАР</span>
              </div>
            </div>
            {dynamicSeats.map((seat, i) => (
              <PlayerSeat key={i} seat={seat} index={i} total={dynamicSeats.length} radius={136} />
            ))}
          </div>
        </div>

        {/* Chat */}
        <div className="w-60 flex flex-col border-l border-primary/15 bg-[#0d0c14] shrink-0 min-h-0 max-sm:w-full max-sm:h-[45%] max-sm:border-l-0 max-sm:border-t max-sm:border-primary/15">
          <div className="px-3 py-2.5 border-b border-primary/15 flex items-center gap-2 shrink-0">
            <div className="w-1.5 h-4 rounded-full bg-primary/60" />
            <h3 className="text-xs font-semibold tracking-wider text-primary uppercase">Чат Бара</h3>
            <span className="ml-auto text-[9px] text-muted-foreground/35">{state.chatMessages.length}</span>
          </div>

          <div className="flex-1 overflow-y-auto px-3 py-3 space-y-3 custom-scrollbar min-h-0" data-testid="chat-messages">
            {state.chatMessages.length === 0 && (
              <p className="text-center text-muted-foreground/40 text-xs py-8">Пока тихо... Напишите первым!</p>
            )}
            {state.chatMessages.map(msg => (
              <MessageRow key={msg.id} msg={msg} isOwn={msg.author === state.player.name} onReact={addReaction} />
            ))}
            {isTyping && (
              <div className="flex items-center gap-1 px-1">
                <span className="text-[10px] text-primary/45">печатаете</span>
                {[0,1,2].map(i => <span key={i} className="typing-dot w-1 h-1 rounded-full bg-primary/40 inline-block" />)}
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="px-2 py-2 border-t border-primary/15 flex flex-col gap-1.5 shrink-0">
            <div className="flex gap-1.5 items-center relative">
              <div className="relative shrink-0">
                <button onClick={() => setEmojiOpen(v => !v)} data-testid="button-emoji"
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-sm transition-all hover:bg-primary/15 border border-primary/20"
                  style={{ color: emojiOpen ? "#f0d080" : "rgba(201,168,76,0.55)" }}>😊</button>
                <AnimatePresence>{emojiOpen && <EmojiPicker onSelect={e => { setInput(v => v + e); setEmojiOpen(false); }} onClose={() => setEmojiOpen(false)} />}</AnimatePresence>
              </div>
              <input value={input} onChange={handleInput} onKeyDown={handleKeyDown}
                placeholder="Сообщение..." data-testid="input-chat" maxLength={MAX_MSG_LEN}
                className="flex-1 min-w-0 text-xs bg-black/40 border border-primary/20 rounded-lg px-2 py-1.5 text-foreground placeholder:text-muted-foreground/30 focus:outline-none focus:border-primary/50 transition-colors" />
              <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
                onClick={handleSend} data-testid="button-send" disabled={!input.trim()}
                className="w-7 h-7 rounded-lg flex items-center justify-center disabled:opacity-30 transition-all text-primary shrink-0"
                style={{ background: input.trim() ? "rgba(201,168,76,0.18)" : "transparent", border: "1px solid rgba(201,168,76,0.3)" }}>
                <Send size={11} />
              </motion.button>
            </div>

            {/* Char counter + quick emojis */}
            <div className="flex items-center justify-between px-0.5">
              <div className="flex gap-1.5">
                {QUICK.map(e => (
                  <button key={e} onClick={() => setInput(v => v + e)} className="text-sm hover:scale-125 transition-transform leading-none" data-testid={`quick-emoji-${e}`}>{e}</button>
                ))}
              </div>
              <span className="text-[9px] tabular-nums"
                style={{ color: remaining < 20 ? "#fb7185" : remaining < 60 ? "#fbbf24" : "rgba(107,114,128,0.6)" }}>
                {remaining}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
