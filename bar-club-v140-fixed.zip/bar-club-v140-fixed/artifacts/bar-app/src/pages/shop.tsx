import { motion } from 'framer-motion';
import { Crown, Check, Gem } from 'lucide-react';
import { useApp } from '../lib/context';
import { useToast } from '../hooks/use-toast';

const CARDS = [
  {
    id: 'Cosmos',
    label: 'Карта «Космос»',
    badge: 'COSMOS',
    price: 500,
    description: 'Загадочный облик звёздного странника',
    gradient: 'linear-gradient(145deg, #0d0b20, #1e1b4b 50%, #0d0b20)',
    border: '#6d28d9',
    glow: 'rgba(109,40,217,0.45)',
    accent: '#a78bfa',
    symbol: '✦',
  },
  {
    id: 'Ruby',
    label: 'Карта «Ruby»',
    badge: 'RUBY',
    price: 1000,
    description: 'Яркий стиль для вечернего образа',
    gradient: 'linear-gradient(145deg, #200510, #4c0519 50%, #200510)',
    border: '#e11d48',
    glow: 'rgba(225,29,72,0.45)',
    accent: '#fb7185',
    symbol: '♦',
  },
  {
    id: 'Platinum',
    label: 'Карта «Platinum»',
    badge: 'PLATINUM',
    price: 2500,
    description: 'Элитный статус участника клуба',
    gradient: 'linear-gradient(145deg, #0d1117, #1e293b 50%, #0d1117)',
    border: '#94a3b8',
    glow: 'rgba(148,163,184,0.35)',
    accent: '#e2e8f0',
    symbol: '★',
  },
  {
    id: 'Diamond',
    label: 'Карта «Diamond»',
    badge: 'DIAMOND',
    price: 5000,
    description: 'Непревзойдённый бриллиантовый уровень',
    gradient: 'linear-gradient(145deg, #040e1c, #0e3460 50%, #040e1c)',
    border: '#38bdf8',
    glow: 'rgba(56,189,248,0.45)',
    accent: '#7dd3fc',
    symbol: '◈',
  },
];

export default function PremiumShop() {
  const { state, setActiveCard, updateBalance } = useApp();
  const { toast } = useToast();
  const { player } = state;

  const handleSelect = (card: typeof CARDS[0]) => {
    if (player.activeCard === card.id) return;
    if (player.balance < card.price) {
      toast({
        title: 'Недостаточно BJT',
        description: `Нужно ${card.price.toLocaleString('ru-RU')} BJT · У вас ${player.balance.toLocaleString('ru-RU')} BJT`,
        variant: 'destructive',
      });
      return;
    }
    updateBalance(-card.price);
    setActiveCard(card.id);
    toast({
      title: 'Карта активирована',
      description: `${card.label} теперь активна`,
      className: 'border-primary bg-card text-primary',
    });
  };

  return (
    <div
      className="min-h-[100dvh] flex flex-col bg-[#0a0a0f] px-4 py-6 gap-5"
      data-testid="screen-shop"
    >
      {/* Header */}
      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
          style={{ background: 'rgba(201,168,76,0.12)', border: '1px solid rgba(201,168,76,0.25)' }}
        >
          <Crown size={20} className="text-primary" />
        </div>
        <div>
          <h1 className="font-serif text-xl gold-gradient-text font-bold tracking-wide">ПРЕМИУМ МАГАЗИН</h1>
          <p className="text-muted-foreground text-xs">Эксклюзивные карты участника</p>
        </div>
      </div>

      {/* Balance bar */}
      <div
        className="rounded-xl px-4 py-3 flex items-center justify-between"
        style={{
          background: 'rgba(201,168,76,0.06)',
          border: '1px solid rgba(201,168,76,0.2)',
        }}
      >
        <span className="text-muted-foreground text-sm">Ваш баланс</span>
        <span className="font-serif text-lg gold-gradient-text font-bold" data-testid="text-shop-balance">
          {player.balance.toLocaleString('ru-RU')} BJT
        </span>
      </div>

      {/* Cards grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {CARDS.map((card, i) => {
          const isActive = player.activeCard === card.id;
          const canAfford = player.balance >= card.price;

          return (
            <motion.div
              key={card.id}
              initial={{ y: 24, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: i * 0.07, duration: 0.4 }}
              data-testid={`card-shop-${card.id.toLowerCase()}`}
              className="card-shimmer rounded-2xl flex flex-col relative"
              style={{
                background: card.gradient,
                border: `1px solid ${isActive ? card.border : card.border + '45'}`,
                boxShadow: isActive
                  ? `0 0 28px ${card.glow}, 0 6px 24px rgba(0,0,0,0.55)`
                  : `0 4px 20px rgba(0,0,0,0.45)`,
                transition: 'box-shadow 0.3s ease, border-color 0.3s ease',
              }}
            >
              {/* Active ribbon */}
              {isActive && (
                <motion.div
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="absolute top-3 right-3 px-2 py-0.5 rounded-full text-[10px] font-bold tracking-widest flex items-center gap-1"
                  style={{
                    background: card.border + '28',
                    border: `1px solid ${card.border}`,
                    color: card.accent,
                  }}
                >
                  <Check size={9} strokeWidth={3} /> АКТИВНО
                </motion.div>
              )}

              <div className="p-5 flex flex-col gap-3 flex-1">
                {/* Icon row */}
                <div className="flex items-start gap-3">
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center text-xl font-serif shrink-0"
                    style={{
                      background: card.border + '1a',
                      color: card.accent,
                      border: `1px solid ${card.border}28`,
                      boxShadow: `inset 0 1px 0 ${card.border}20`,
                    }}
                  >
                    {card.symbol}
                  </div>
                  <div className="mt-0.5">
                    <span
                      className="text-[10px] font-bold tracking-[0.2em] px-2 py-0.5 rounded"
                      style={{ background: card.border + '20', color: card.accent }}
                    >
                      {card.badge}
                    </span>
                    <p className="text-foreground/90 font-semibold text-sm mt-1 font-serif leading-tight">
                      {card.label}
                    </p>
                  </div>
                </div>

                <p className="text-muted-foreground/80 text-xs leading-relaxed">{card.description}</p>

                <div className="h-px" style={{ background: `linear-gradient(90deg, transparent, ${card.border}30, transparent)` }} />

                {/* Price + button */}
                <div className="flex items-center justify-between mt-auto">
                  <div className="flex items-center gap-1.5">
                    <Gem size={13} style={{ color: card.accent }} />
                    <span className="font-serif font-bold text-sm" style={{ color: card.accent }}>
                      {card.price.toLocaleString('ru-RU')} BJT
                    </span>
                  </div>

                  <motion.button
                    whileHover={!isActive && canAfford ? { scale: 1.05 } : {}}
                    whileTap={!isActive ? { scale: 0.95 } : {}}
                    onClick={() => handleSelect(card)}
                    disabled={isActive}
                    data-testid={`button-select-${card.id.toLowerCase()}`}
                    className="px-4 py-1.5 rounded-lg text-xs font-bold tracking-wider transition-all"
                    style={{
                      background: isActive
                        ? card.border + '18'
                        : canAfford
                          ? card.border
                          : 'rgba(255,255,255,0.04)',
                      border: `1px solid ${card.border}`,
                      color: isActive
                        ? card.accent
                        : canAfford
                          ? '#050505'
                          : card.accent + '70',
                      boxShadow: !isActive && canAfford ? `0 0 14px ${card.glow}` : 'none',
                      cursor: isActive ? 'default' : 'pointer',
                    }}
                  >
                    {isActive ? 'АКТИВНА' : canAfford ? 'ВЫБРАТЬ' : 'МАЛО BJT'}
                  </motion.button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
