# БАР Знакомств!

VK Mini App с премиальным тёмным барным визуалом: вход, главный экран, круглый стол участников, чат, магазин карт и профиль.

## Run & Operate

- `pnpm --filter @workspace/bar-app run dev` — frontend dev server, default port 5173.
- `pnpm --filter @workspace/api-server run dev` — API server, default port 3000 if `PORT` is not set.
- `pnpm run typecheck` — typecheck workspace.
- `pnpm run build` — typecheck + build packages.

## Important project constants

- VK Mini App ID: `54584981`.
- Admin VK ID: `1057236881`.
- App version: `artifacts/bar-app/src/lib/vk.ts`.

## Product rules

- Do not change the core visual style: dark bar background, gold accents, main menu, table, chat and profile style should remain recognizable.
- Avoid gambling-risk wording in UI copy: no gambling-risk wording or similar promises.
- Admin UI must not be visible to regular VK users.

## Current limitations

- Balance, shop purchases, chat and admin actions are still local frontend state. They need server persistence before production.
- VK Bridge is wired with a runtime fallback; for production, bundle `@vkontakte/vk-bridge` through dependencies.
