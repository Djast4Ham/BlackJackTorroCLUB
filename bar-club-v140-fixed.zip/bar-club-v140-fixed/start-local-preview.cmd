@echo off
cd /d "%~dp0dist\public"
where python >nul 2>nul
if %errorlevel%==0 (
  start "" http://localhost:5173
  python -m http.server 5173
) else (
  where py >nul 2>nul
  if %errorlevel%==0 (
    start "" http://localhost:5173
    py -m http.server 5173
  ) else (
    echo Python не найден. Откройте dist\public\index.html двойным кликом или установите Python.
    pause
  )
)
