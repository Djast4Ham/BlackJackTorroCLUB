# БАР Знакомств! — VK Mini App

Чистый релизный исходник мини-приложения с тёмным барным визуалом, нижним меню, столом участников, чатом, магазином карт и профилем.

## Что изменено в v1.0.40

- Убраны старые DEMO-маркировки `v1.0.31`; версия вынесена в `artifacts/bar-app/src/lib/vk.ts`.
- Добавлена базовая VK runtime-логика: чтение `vk_user_id`, попытка инициализации VK Bridge, подстановка имени/аватара пользователя.
- Админ-кнопка скрыта для всех, кроме VK ID `1057236881`; в локальной dev-среде без VK доступ разрешён для проверки.
- Убраны рискованные формулировки из чата и магазина.
- Чат визуально очищен: сообщения теперь без рамок/пузырей, текст выглядит легче.
- Бар адаптирован под маленькие экраны: стол и чат перестраиваются вертикально.
- Исправлены дефолтные env для локального запуска Vite/API.
- API logger упрощён, чтобы не тянуть worker-пути `pino-pretty` в production bundle.
- Архив очищен от `.git`, `.local`, cache и лишних артефактов окружения.

## Команды запуска

```bash
corepack enable
corepack prepare pnpm@latest --activate
pnpm install

# Frontend
cd artifacts/bar-app
pnpm run dev

# API, отдельно
cd ../api-server
PORT=3000 pnpm run dev
```

Для frontend по умолчанию используется порт `5173`, `BASE_PATH=/`. При деплое во VK Mini Apps укажите production URL в настройках приложения VK.

## VK Mini App

- VK Mini App ID: `54584981`
- Admin VK ID: `1057236881`
- Основная конфигурация: `artifacts/bar-app/src/lib/vk.ts`

Для полноценного production-варианта рекомендуется установить и бандлить `@vkontakte/vk-bridge`, а не полагаться только на CDN-скрипт из `index.html`.

## Структура

```text
artifacts/bar-app/      React/Vite frontend
artifacts/api-server/   Express API
lib/api-*               generated API helpers
lib/db                  DB schema placeholder
scripts                 workspace scripts
```

## Перед модерацией VK

1. Собрать frontend: `pnpm --filter @workspace/bar-app run build`.
2. Проверить экран входа, главную, бар, магазин и профиль на мобильной ширине 375px.
3. Проверить, что admin-кнопка видна только под VK ID администратора.
4. Проверить все тексты на отсутствие обещаний результата и рискованных механик.
5. Подключить реальные backend-эндпоинты для баланса, покупок, чата и админ-действий.
