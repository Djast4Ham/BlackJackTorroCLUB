# Локальный preview без установки зависимостей

Этот preview нужен, чтобы быстро проверить визуал архива без `pnpm install`.

## Windows
Дважды нажмите `start-local-preview.cmd` или выполните в CMD:

```cmd
cd Bar-Club
start-local-preview.cmd
```

Откроется: http://localhost:5173

## macOS/Linux

```bash
cd Bar-Club
./start-local-preview.sh
```

## Без сервера
Можно открыть файл напрямую:

```text
dist/public/index.html
```

Основной React/Vite исходник находится в `artifacts/bar-app`.
